<?php
$page_title = 'About Us — Aadhiya Shakti Academy';
$page_description = 'The story, founders, and mission behind Aadhiya Shakti Academy.';
require_once __DIR__ . '/includes/header.php';
require_once __DIR__ . '/includes/data.php';
?>

<section class="page-header">
  <div class="container">
    <span class="eyebrow">Our Story</span>
    <h1>About Aadhiya Shakti Academy</h1>
    <p>How the academy started, what it stands for, and who's behind it.</p>
  </div>
</section>

<section style="padding-top:0;">
  <div class="container" style="max-width:900px; display:grid; grid-template-columns: 1fr 1.2fr; gap:40px; align-items:center;">
    <div class="img-tint img-tint--dance" style="aspect-ratio:4/5;">
      <img src="<?= htmlspecialchars(get_site_image('about_main', IMG_BHARATANATYAM)) ?>" alt="Aadhiya Shakti Academy" style="width:100%; height:100%; object-fit:cover;">
    </div>
    <div>
      <p style="color:var(--charcoal-soft); font-size:1.05rem; margin-bottom:24px;">
        Aadhiya Shakti Academy was started by Harshal Mehta and Tamanna Dama while they were studying BCA (Bachelor of Computer Applications), as part of an academic requirement and project initiative that grew into the academy concept presented here.
      </p>

      <div class="info-note">
        <strong>Established:</strong> [YEAR TO BE CONFIRMED] &nbsp;·&nbsp; <strong>Started in:</strong> [CITY TO BE CONFIRMED]
      </div>

      <p style="color:var(--charcoal-soft); margin-top:20px;">
        What began as a structured academic project has been developed here into a full concept for a dance, singing, music and choreography academy — covering course design, instructor profiles, and an event choreography service, built out to demonstrate how such a platform could work end to end.
      </p>
    </div>
  </div>
</section>

<style>
  @media (max-width: 780px) {
    section > .container[style*="grid-template-columns: 1fr 1.2fr"] { grid-template-columns: 1fr !important; }
  }
</style>

<!-- MISSION & VISION -->
<section style="background:var(--paper);">
  <div class="container" style="display:grid; grid-template-columns:1fr 1fr; gap:40px; max-width:900px; margin:0 auto;">
    <div>
      <h2>Mission</h2>
      <p style="color:var(--charcoal-soft); margin-top:12px;">Promote accessible, structured learning in dance, singing, music, and choreography — for beginners and advanced learners alike.</p>
    </div>
    <div>
      <h2>Vision</h2>
      <p style="color:var(--charcoal-soft); margin-top:12px;">Create a creative environment where learners can practice, collaborate, perform, and build confidence through artistic expression.</p>
    </div>
  </div>
</section>

<!-- FOUNDERS -->
<section>
  <div class="container" style="max-width:900px;">
    <div class="section-head">
      <span class="eyebrow">Founders</span>
      <h2>Started as a student project</h2>
    </div>
    <div class="founder-grid">
      <div class="founder-card">
        <h3>Harshal Mehta</h3>
        <p style="color:var(--terracotta); font-size:0.85rem; font-weight:700; margin:6px 0 14px;">Founder / Co-Founder</p>
        <p style="color:var(--charcoal-soft); font-size:0.95rem;">Started the Aadhiya Shakti Academy concept while studying BCA — the project began as an academic requirement that developed into this academy concept.</p>
      </div>
      <div class="founder-card">
        <h3>Tamanna Dama</h3>
        <p style="color:var(--terracotta); font-size:0.85rem; font-weight:700; margin:6px 0 14px;">Co-Founder</p>
        <p style="color:var(--charcoal-soft); font-size:0.95rem;">Started the Aadhiya Shakti Academy concept while studying BCA — the project began as an academic requirement that developed into this academy concept.</p>
      </div>
    </div>
  </div>
</section>

<!-- CUSTOMER EXPERIENCE -->
<section style="background:var(--paper);">
  <div class="container">
    <div class="section-head">
      <span class="eyebrow">Sample Testimonials</span>
      <h2>Customer Experience</h2>
      <p>The reviews below are sample/demo content written for this project, not verified real customer reviews.</p>
    </div>
    <div class="testimonial-grid">
      <?php foreach (array_slice(get_testimonials(), 0, 3) as $t): ?>
        <div class="testimonial-card">
          <div class="stars">★★★★★</div>
          <p class="quote">&ldquo;<?= htmlspecialchars($t['quote']) ?>&rdquo;</p>
          <div class="testimonial-person"><?= htmlspecialchars($t['name']) ?><span><?= htmlspecialchars($t['service']) ?></span></div>
        </div>
      <?php endforeach; ?>
    </div>
  </div>
</section>

<section>
  <div class="container">
    <div class="cta-band">
      <h2>Want to know more?</h2>
      <p>Browse our courses or get in touch with any questions about the academy.</p>
      <div class="cta-actions">
        <a href="courses.php" class="btn btn-coral">Explore Courses</a>
        <a href="contact.php" class="btn btn-outline" style="border-color:var(--ivory); color:var(--ivory);">Contact Us</a>
      </div>
    </div>
  </div>
</section>

<?php require_once __DIR__ . '/includes/footer.php'; ?>
