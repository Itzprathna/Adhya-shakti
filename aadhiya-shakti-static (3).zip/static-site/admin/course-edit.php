<?php
require_once __DIR__ . '/../includes/config.php';
require_once __DIR__ . '/../includes/data.php';
admin_require_login();
admin_require_permission('manage_courses');

$id = (int) ($_GET['id'] ?? $_POST['id'] ?? 0);
$course = null;
if ($id) {
    $s = db()->prepare('SELECT * FROM courses WHERE id = ?');
    $s->execute([$id]);
    $course = $s->fetch() ?: null;
    if (!$course) { toast_set('Course not found.', 'error'); redirect('courses.php'); }
}

$cats = db()->query('SELECT id, name FROM categories ORDER BY name')->fetchAll();
$subs = db()->query('SELECT id, category_id, name FROM subcategories ORDER BY name')->fetchAll();
$tutors = db()->query("SELECT slug, name FROM tutors WHERE status='active' ORDER BY name")->fetchAll();
$error = null;
$f = $course ?: ['title'=>'','slug'=>'','category_id'=>0,'subcategory_id'=>null,'instructor_slug'=>'','level'=>'Beginner','duration'=>'','mode'=>'Online','price'=>'','price_note'=>'Sample Pricing','image'=>'','excerpt'=>'','description'=>'','outcomes'=>'','status'=>'active'];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!csrf_verify($_POST['csrf_token'] ?? null)) {
        $error = 'Your session expired. Please try again.';
    } else {
        foreach (['title','slug','level','duration','mode','price','price_note','excerpt','description','outcomes','instructor_slug','status'] as $k) {
            $f[$k] = trim((string) ($_POST[$k] ?? ''));
        }
        $f['category_id']    = (int) ($_POST['category_id'] ?? 0);
        $f['subcategory_id'] = (int) ($_POST['subcategory_id'] ?? 0) ?: null;
        $f['slug'] = slugify($f['slug'] !== '' ? $f['slug'] : $f['title']);
        if (!in_array($f['status'], ['active','inactive'], true)) { $f['status'] = 'active'; }

        $up = null;
        if ($f['title'] === '' || $f['price'] === '' || !$f['category_id']) {
            $error = 'Title, category and price are required.';
        } else {
            $dup = db()->prepare('SELECT COUNT(*) FROM courses WHERE slug = ? AND id <> ?');
            $dup->execute([$f['slug'], $id]);
            if ($dup->fetchColumn()) { $error = 'Another course already uses the slug “' . $f['slug'] . '”.'; }
        }
        if (!$error && isset($_FILES['image']) && $_FILES['image']['error'] !== UPLOAD_ERR_NO_FILE) {
            // Changing the image needs its own permission
            if (!admin_can('manage_course_images')) {
                $error = 'You do not have permission to upload course images.';
            } else {
                $up = save_uploaded_image('image', 'course');
                if (isset($up['error'])) { $error = $up['error']; }
            }
        }
        if (!$error) {
            $oldImage = $course['image'] ?? '';
            $image = $oldImage;
            if (!empty($up['path'])) { $image = $up['path']; }
            $tutor = $f['instructor_slug'] !== '' ? $f['instructor_slug'] : null;
            if ($course) {
                db()->prepare('UPDATE courses SET category_id=?, subcategory_id=?, instructor_slug=?, title=?, slug=?, level=?, duration=?, mode=?, price=?, price_note=?, image=?, excerpt=?, description=?, outcomes=?, status=? WHERE id=?')
                    ->execute([$f['category_id'],$f['subcategory_id'],$tutor,$f['title'],$f['slug'],$f['level'],$f['duration'],$f['mode'],$f['price'],$f['price_note'],$image,$f['excerpt'],$f['description'],$f['outcomes'],$f['status'],$id]);
                if (!empty($up['path'])) { delete_uploaded_image($oldImage); }
                admin_log('course_update', 'Edited course "' . $f['title'] . '"');
                toast_set('Course updated.');
            } else {
                db()->prepare('INSERT INTO courses (category_id, subcategory_id, instructor_slug, title, slug, level, duration, mode, price, price_note, image, excerpt, description, outcomes, status) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)')
                    ->execute([$f['category_id'],$f['subcategory_id'],$tutor,$f['title'],$f['slug'],$f['level'],$f['duration'],$f['mode'],$f['price'],$f['price_note'],$image,$f['excerpt'],$f['description'],$f['outcomes'],$f['status']]);
                admin_log('course_create', 'Added course "' . $f['title'] . '"');
                toast_set('Course added.');
            }
            redirect('courses.php');
        }
        $f['image'] = $course['image'] ?? '';
    }
}

$admin_page_title = $course ? 'Edit Course' : 'Add Course';
require_once __DIR__ . '/../includes/admin-header.php';
?>
<h1><?= e($admin_page_title) ?></h1>
<p style="margin-bottom:18px;"><a href="courses.php" style="color:var(--terracotta);font-weight:700;">← Back to courses</a></p>
<?php if ($error): ?><div class="admin-alert admin-alert-error"><?= e($error) ?></div><?php endif; ?>

<form method="post" enctype="multipart/form-data" class="form-card">
  <input type="hidden" name="csrf_token" value="<?= e(csrf_token()) ?>"><input type="hidden" name="id" value="<?= $id ?>">
  <div class="form-grid">
    <div class="form-row"><label>Title *</label><input name="title" required value="<?= e($f['title']) ?>"></div>
    <div class="form-row"><label>URL slug (blank = from title)</label><input name="slug" value="<?= e($f['slug']) ?>"></div>
    <div class="form-row"><label>Category *</label>
      <select name="category_id" id="catSel" required><option value="">Choose…</option>
        <?php foreach ($cats as $c): ?><option value="<?= $c['id'] ?>" <?= (int) $f['category_id'] === (int) $c['id'] ? 'selected' : '' ?>><?= e($c['name']) ?></option><?php endforeach; ?>
      </select></div>
    <div class="form-row"><label>Subcategory</label><select name="subcategory_id" id="subSel"><option value="">None</option></select></div>
    <div class="form-row"><label>Tutor</label>
      <select name="instructor_slug"><option value="">No single tutor</option>
        <?php foreach ($tutors as $t): ?><option value="<?= e($t['slug']) ?>" <?= $f['instructor_slug'] === $t['slug'] ? 'selected' : '' ?>><?= e($t['name']) ?></option><?php endforeach; ?>
      </select></div>
    <div class="form-row"><label>Level</label><select name="level">
      <?php foreach (['Beginner','Intermediate','Advanced','All Levels'] as $l): ?><option <?= $f['level'] === $l ? 'selected' : '' ?>><?= $l ?></option><?php endforeach; ?></select></div>
    <div class="form-row"><label>Duration</label><input name="duration" value="<?= e($f['duration']) ?>" placeholder="12 Weeks"></div>
    <div class="form-row"><label>Mode</label><select name="mode">
      <?php foreach (['Online','In-Studio','Online + In-Studio','On-Location'] as $l): ?><option <?= $f['mode'] === $l ? 'selected' : '' ?>><?= $l ?></option><?php endforeach; ?></select></div>
    <div class="form-row"><label>Price *</label><input name="price" required value="<?= e($f['price']) ?>" placeholder="₹2,499/month"></div>
    <div class="form-row"><label>Price note</label><select name="price_note">
      <?php foreach (['Sample Pricing','Starting From'] as $l): ?><option <?= $f['price_note'] === $l ? 'selected' : '' ?>><?= $l ?></option><?php endforeach; ?></select></div>
    <div class="form-row"><label>Status</label><select name="status"><option value="active" <?= $f['status']==='active'?'selected':'' ?>>Active (visible)</option><option value="inactive" <?= $f['status']==='inactive'?'selected':'' ?>>Inactive (hidden)</option></select></div>
  </div>
  <div class="form-row"><label>Short description</label><input name="excerpt" maxlength="400" value="<?= e((string) $f['excerpt']) ?>"></div>
  <div class="form-row"><label>Full description</label><textarea name="description" rows="4"><?= e((string) $f['description']) ?></textarea></div>
  <div class="form-row"><label>What students learn (one per line)</label><textarea name="outcomes" rows="4"><?= e((string) $f['outcomes']) ?></textarea></div>

  <div class="form-row">
    <label>Course image <?= admin_can('manage_course_images') ? '' : '(you cannot change this)' ?></label>
    <div style="display:flex; gap:18px; align-items:center; flex-wrap:wrap;">
      <img id="imgPrev" class="img-preview" src="<?= e(admin_img($f['image'])) ?>" alt="Preview">
      <div>
        <input type="file" name="image" accept="image/jpeg,image/png,image/webp,image/gif" data-preview="#imgPrev" <?= admin_can('manage_course_images') ? '' : 'disabled' ?>>
        <p style="font-size:.78rem;color:var(--charcoal-soft);margin-top:6px;">JPG, PNG, WEBP or GIF, up to 5 MB. Leave empty to keep the current image.</p>
      </div>
    </div>
  </div>
  <button class="btn btn-primary" type="submit"><?= $course ? 'Save changes' : 'Add course' ?></button>
</form>
<script>
var SUBS = <?= json_encode($subs) ?>, CURRENT = <?= json_encode((int) $f['subcategory_id']) ?>;
function fillSubs() {
  var c = document.getElementById('catSel').value, s = document.getElementById('subSel');
  s.innerHTML = '<option value="">None</option>';
  SUBS.filter(function (x) { return String(x.category_id) === c; }).forEach(function (x) {
    var o = document.createElement('option'); o.value = x.id; o.textContent = x.name;
    if (x.id == CURRENT) o.selected = true; s.appendChild(o);
  });
}
document.getElementById('catSel').addEventListener('change', function () { CURRENT = 0; fillSubs(); });
fillSubs();
</script>
<?php require_once __DIR__ . '/../includes/admin-footer.php'; ?>
