<?php
require_once __DIR__ . '/../includes/config.php';
require_once __DIR__ . '/../includes/data.php';
admin_require_login();
admin_require_permission('manage_courses');

// ---- Delete / status toggle (POST only, CSRF protected) ----
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!csrf_verify($_POST['csrf_token'] ?? null)) {
        toast_set('Your session expired. Please try again.', 'error');
    } else {
        $id = (int) ($_POST['id'] ?? 0);
        $row = db()->prepare('SELECT title, image FROM courses WHERE id = ?');
        $row->execute([$id]);
        $c = $row->fetch();
        if ($c && ($_POST['action'] ?? '') === 'delete') {
            db()->prepare('DELETE FROM courses WHERE id = ?')->execute([$id]);
            delete_uploaded_image($c['image']);
            admin_log('course_delete', 'Deleted course "' . $c['title'] . '"');
            toast_set('Course "' . $c['title'] . '" deleted.');
        } elseif ($c && ($_POST['action'] ?? '') === 'toggle') {
            db()->prepare("UPDATE courses SET status = IF(status='active','inactive','active') WHERE id = ?")->execute([$id]);
            admin_log('course_status', 'Toggled status of "' . $c['title'] . '"');
            toast_set('Status updated for "' . $c['title'] . '".');
        }
    }
    redirect('courses.php');
}

$total = (int) db()->query('SELECT COUNT(*) FROM courses')->fetchColumn();
$q   = trim((string) ($_GET['q'] ?? ''));
$cat = (int) ($_GET['cat'] ?? 0);
$st  = (string) ($_GET['status'] ?? '');

$sql = 'SELECT c.*, cat.name AS cat_name, sc.name AS sub_name, t.name AS tutor_name
          FROM courses c JOIN categories cat ON cat.id = c.category_id
          LEFT JOIN subcategories sc ON sc.id = c.subcategory_id
          LEFT JOIN tutors t ON t.slug = c.instructor_slug WHERE 1=1';
$args = [];
if ($q !== '')  { $sql .= ' AND (c.title LIKE ? OR c.slug LIKE ?)'; $args[] = "%$q%"; $args[] = "%$q%"; }
if ($cat)       { $sql .= ' AND c.category_id = ?'; $args[] = $cat; }
if (in_array($st, ['active', 'inactive'], true)) { $sql .= ' AND c.status = ?'; $args[] = $st; }
$sql .= ' ORDER BY c.id DESC';
$stmt = db()->prepare($sql);
$stmt->execute($args);
$rows = $stmt->fetchAll();
$cats = db()->query('SELECT id, name FROM categories ORDER BY name')->fetchAll();

$admin_page_title = 'Courses';
require_once __DIR__ . '/../includes/admin-header.php';
?>
<div style="display:flex; justify-content:space-between; align-items:center; flex-wrap:wrap; gap:12px;">
  <div><h1>Courses</h1><p style="color:var(--charcoal-soft);"><?= $total ?> total · changes appear on the public site immediately.</p></div>
  <a href="course-edit.php" class="btn btn-primary btn-sm">+ Add Course</a>
</div>

<?php if ($total === 0): ?>
  <div class="admin-alert admin-alert-error" style="margin-top:18px;">
    No courses in the database yet — the public site is showing the built-in list.
    Run <a href="../database/migrate.php" style="text-decoration:underline;">database/migrate.php</a> once to copy them here so you can edit them.
  </div>
<?php endif; ?>

<form class="filters" method="get">
  <input type="search" name="q" placeholder="Search title…" value="<?= e($q) ?>">
  <select name="cat"><option value="0">All categories</option>
    <?php foreach ($cats as $c): ?><option value="<?= $c['id'] ?>" <?= $cat === (int) $c['id'] ? 'selected' : '' ?>><?= e($c['name']) ?></option><?php endforeach; ?>
  </select>
  <select name="status"><option value="">Any status</option>
    <option value="active" <?= $st === 'active' ? 'selected' : '' ?>>Active</option>
    <option value="inactive" <?= $st === 'inactive' ? 'selected' : '' ?>>Inactive</option>
  </select>
  <button class="btn btn-outline btn-sm" type="submit">Filter</button>
</form>

<div class="tbl-wrap"><table class="tbl">
  <thead><tr><th>Image</th><th>Course</th><th>Category</th><th>Tutor</th><th>Price</th><th>Status</th><th>Actions</th></tr></thead>
  <tbody>
  <?php foreach ($rows as $r): ?>
    <tr>
      <td><img class="thumb" src="<?= e(admin_img($r['image'])) ?>" alt=""></td>
      <td><strong><?= e($r['title']) ?></strong><br><span style="font-size:.78rem;color:var(--charcoal-soft);"><?= e($r['level']) ?> · <?= e($r['duration']) ?></span></td>
      <td><?= e($r['cat_name']) ?><br><span style="font-size:.78rem;color:var(--charcoal-soft);"><?= e((string) $r['sub_name']) ?></span></td>
      <td><?= e((string) ($r['tutor_name'] ?? '—')) ?></td>
      <td><?= e($r['price']) ?></td>
      <td><span class="badge <?= $r['status'] === 'active' ? 'on' : 'off' ?>"><?= e($r['status']) ?></span></td>
      <td style="white-space:nowrap;">
        <a class="btn-link" href="course-edit.php?id=<?= $r['id'] ?>">Edit</a>
        <form method="post" style="display:inline;">
          <input type="hidden" name="csrf_token" value="<?= e(csrf_token()) ?>"><input type="hidden" name="id" value="<?= $r['id'] ?>"><input type="hidden" name="action" value="toggle">
          <button class="btn-link" type="submit"><?= $r['status'] === 'active' ? 'Deactivate' : 'Activate' ?></button>
        </form>
        <form method="post" style="display:inline;" data-confirm="Delete “<?= e($r['title']) ?>”? This cannot be undone.">
          <input type="hidden" name="csrf_token" value="<?= e(csrf_token()) ?>"><input type="hidden" name="id" value="<?= $r['id'] ?>"><input type="hidden" name="action" value="delete">
          <button class="btn-link danger" type="submit">Delete</button>
        </form>
      </td>
    </tr>
  <?php endforeach; ?>
  <?php if (!$rows): ?><tr><td colspan="7" style="text-align:center;color:var(--charcoal-soft);padding:30px;">No courses found.</td></tr><?php endif; ?>
  </tbody>
</table></div>
<?php require_once __DIR__ . '/../includes/admin-footer.php'; ?>
