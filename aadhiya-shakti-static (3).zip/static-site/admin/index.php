<?php
require_once __DIR__ . '/../includes/config.php';
require_once __DIR__ . '/../includes/data.php';
admin_require_login();

$pdo = db();
$one = fn(string $sql) => (int) $pdo->query($sql)->fetchColumn();
$newMsgs   = admin_can('manage_messages') ? $one("SELECT COUNT(*) FROM contact_messages WHERE status='new'") : 0;
$totalMsgs = admin_can('manage_messages') ? $one('SELECT COUNT(*) FROM contact_messages') : 0;
$courseCount = count(get_courses());
$tutorCount  = count(get_instructors());
$adminCount  = $one('SELECT COUNT(*) FROM admin_users');
$recent = [];
if (admin_can('manage_admins')) {
    try { $recent = $pdo->query('SELECT * FROM admin_activity_log ORDER BY id DESC LIMIT 8')->fetchAll(); } catch (Throwable $e) {}
}
$me = admin_current();
$admin_page_title = 'Dashboard';
require_once __DIR__ . '/../includes/admin-header.php';
?>
<h1>Welcome back, <?= e($me['username']) ?></h1>
<p style="color:var(--charcoal-soft);">Role: <strong><?= e(ADMIN_ROLES[$me['role']]['label'] ?? $me['role']) ?></strong> · <?= e(date('l, j F Y')) ?></p>

<?php
$ico = fn(string $d) => '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round">' . $d . '</svg>';
$cards = [
  [$courseCount, 'Total Courses', '<path d="M4 5a2 2 0 0 1 2-2h13v16H6a2 2 0 0 0-2 2z"/>'],
  [$tutorCount,  'Total Tutors',  '<circle cx="12" cy="8" r="4"/><path d="M4 21a8 8 0 0 1 16 0"/>'],
  [$adminCount,  'Admin Members', '<circle cx="9" cy="8" r="3.5"/><path d="M2 20a7 7 0 0 1 14 0"/>'],
];
if (admin_can('manage_messages')) {
  $cards[] = [$totalMsgs, 'Contact Enquiries', '<rect x="3" y="5" width="18" height="14" rx="2"/><path d="M3 7l9 6 9-6"/>'];
  $cards[] = [$newMsgs,   'New Messages',      '<path d="M18 8a6 6 0 0 0-12 0c0 7-3 8-3 8h18s-3-1-3-8"/><path d="M10 21a2 2 0 0 0 4 0"/>'];
}
$perCat = [];
try { $perCat = $pdo->query('SELECT c.name, COUNT(co.id) n FROM categories c LEFT JOIN courses co ON co.category_id = c.id GROUP BY c.id ORDER BY n DESC')->fetchAll(); } catch (Throwable $e) {}
$maxCat = max(1, ...array_column($perCat ?: [['n' => 1]], 'n'));
$latestMsgs = [];
if (admin_can('manage_messages')) { try { $latestMsgs = $pdo->query('SELECT * FROM contact_messages ORDER BY id DESC LIMIT 4')->fetchAll(); } catch (Throwable $e) {} }
?>
<div class="admin-stats">
  <?php foreach ($cards as [$n, $label, $path]): ?>
    <div class="admin-stat"><div class="sico"><?= $ico($path) ?></div><div><div class="num" data-count="<?= (int) $n ?>">0</div><div class="label"><?= e($label) ?></div></div></div>
  <?php endforeach; ?>
</div>

<div class="qgrid">
  <?php if (admin_can('manage_courses')): ?><a class="qcard" href="course-edit.php"><span class="plus">+</span> Add Course</a><?php endif; ?>
  <?php if (admin_can('manage_tutors')): ?><a class="qcard" href="tutor-edit.php"><span class="plus">+</span> Add Tutor</a><?php endif; ?>
  <?php if (admin_can('manage_admins')): ?><a class="qcard" href="member-edit.php"><span class="plus">+</span> Add Admin</a><?php endif; ?>
  <?php if (admin_can('manage_photos')): ?><a class="qcard" href="media.php"><span class="plus">↑</span> Upload Photos</a><?php endif; ?>
</div>

<div class="dash-cols">
  <div class="admin-card">
    <h3 style="margin-bottom:6px;">Courses by category</h3>
    <?php foreach ($perCat as $c): ?>
      <div class="bar-row"><span><?= e($c['name']) ?></span><div class="bar"><i data-w="<?= round($c['n'] / $maxCat * 100) ?>"></i></div><span><?= (int) $c['n'] ?></span></div>
    <?php endforeach; ?>
    <?php if (!$perCat): ?><p style="color:var(--charcoal-soft);">Run database setup to see categories.</p><?php endif; ?>
  </div>

  <div>
    <?php if (admin_can('manage_messages')): ?>
    <div class="admin-card">
      <h3 style="margin-bottom:10px;">Latest enquiries</h3>
      <?php foreach ($latestMsgs as $m): ?>
        <div style="padding:8px 0;border-top:1px solid var(--border);font-size:.86rem;"><strong><?= e($m['name'] ?? '') ?></strong> <?= ($m['status'] ?? '') === 'new' ? '<span class="badge">new</span>' : '' ?><br><span style="color:var(--charcoal-soft);"><?= e(mb_strimwidth((string) ($m['message'] ?? ''), 0, 70, '…')) ?></span></div>
      <?php endforeach; ?>
      <?php if (!$latestMsgs): ?><p style="color:var(--charcoal-soft);">No enquiries yet.</p><?php endif; ?>
      <p style="margin-top:10px;"><a href="messages.php" style="color:var(--terracotta);font-weight:700;">Open inbox →</a></p>
    </div>
    <?php endif; ?>
    <?php if (admin_can('manage_admins')): ?>
    <div class="admin-card">
      <h3 style="margin-bottom:10px;">Recent activity</h3>
      <?php foreach ($recent as $r): ?>
        <div style="padding:7px 0;border-top:1px solid var(--border);font-size:.84rem;"><strong><?= e($r['admin_username']) ?></strong> — <?= e($r['description'] ?: $r['action']) ?><br><span style="color:var(--charcoal-soft);font-size:.75rem;"><?= e($r['created_at']) ?></span></div>
      <?php endforeach; ?>
      <?php if (!$recent): ?><p style="color:var(--charcoal-soft);">Nothing yet.</p><?php else: ?><p style="margin-top:10px;"><a href="activity.php" style="color:var(--terracotta);font-weight:700;">Full log →</a></p><?php endif; ?>
    </div>
    <?php endif; ?>
  </div>
</div>
<script>
document.querySelectorAll('[data-count]').forEach(function (el) {
  var end = +el.dataset.count, t0 = null;
  function step(t) { t0 = t0 || t; var p = Math.min((t - t0) / 800, 1); el.textContent = Math.round(end * (1 - Math.pow(1 - p, 3))); if (p < 1) requestAnimationFrame(step); }
  requestAnimationFrame(step);
});
setTimeout(function () { document.querySelectorAll('.bar i').forEach(function (i) { i.style.width = i.dataset.w + '%'; }); }, 80);
</script>
<?php require_once __DIR__ . '/../includes/admin-footer.php'; ?>
