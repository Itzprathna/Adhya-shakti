<?php
require_once __DIR__ . '/../includes/config.php';

if (admin_is_logged_in()) {
    redirect('index.php');
}

$error = null;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!csrf_verify($_POST['csrf_token'] ?? null)) {
        $error = 'Your session expired. Please try again.';
    } else {
        $username = trim((string) ($_POST['username'] ?? ''));
        $password = (string) ($_POST['password'] ?? '');
        $admin = admin_attempt_login($username, $password);
        if ($admin) {
            redirect('index.php');
        } else {
            $error = 'Incorrect username or password.';
        }
    }
}
?>
<!doctype html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Admin Login — <?= e(SITE_NAME) ?></title>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link href="https://fonts.googleapis.com/css2?family=Fraunces:opsz,wght@9..144,600;9..144,700&family=Manrope:wght@400;500;600;700&display=swap" rel="stylesheet">
<link rel="stylesheet" href="../assets/css/style.css">
<link rel="icon" type="image/png" href="../assets/images/logo.png">
</head>
<body style="min-height:100vh; display:flex; align-items:center; justify-content:center;">

<div class="form-card" style="max-width:400px; width:100%; margin:20px;">
  <div style="text-align:center; margin-bottom:24px;">
    <img src="../assets/images/logo.png" alt="Aadhiya Shakti Academy" style="width:56px; height:56px; object-fit:contain; margin:0 auto 10px;">
    <h2 style="font-size:1.3rem;">Admin Login</h2>
    <p style="color:var(--charcoal-soft); font-size:0.85rem; margin-top:4px;">Manage courses, tutors, messages and photos</p>
  </div>

  <?php if ($error): ?>
    <div class="form-success" style="display:block; background:var(--peach); color:var(--terracotta);"><?= e($error) ?></div>
  <?php endif; ?>

  <form method="post" action="login.php">
    <input type="hidden" name="csrf_token" value="<?= e(csrf_token()) ?>">
    <div class="form-row">
      <label for="username">Username</label>
      <input type="text" id="username" name="username" required autofocus value="<?= e($_POST['username'] ?? '') ?>">
    </div>
    <div class="form-row">
      <label for="password">Password</label>
      <input type="password" id="password" name="password" required>
    </div>
    <button type="submit" class="btn btn-primary" style="width:100%; justify-content:center;">Log In</button>
  </form>

  <p style="text-align:center; margin-top:20px; font-size:0.82rem;">
    <a href="../index.php" style="color:var(--terracotta); font-weight:600;">← Back to the site</a>
  </p>
</div>

</body>
</html>
