<?php
require_once __DIR__ . '/../includes/config.php';

if (admin_is_logged_in()) {
    admin_log('logout', 'Logged out.');
}

// Destroy the whole session, expire the cookie, then go to the PUBLIC homepage.
$_SESSION = [];
if (ini_get('session.use_cookies')) {
    $p = session_get_cookie_params();
    setcookie(session_name(), '', time() - 42000, $p['path'], $p['domain'], (bool) $p['secure'], (bool) $p['httponly']);
}
session_destroy();

redirect('../index.php');
