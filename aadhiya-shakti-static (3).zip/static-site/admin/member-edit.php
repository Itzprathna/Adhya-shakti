<?php
require_once __DIR__ . '/../includes/config.php';
admin_require_login();
admin_require_permission('manage_admins');

$id = (int) ($_GET['id'] ?? $_POST['id'] ?? 0);
$m = null;
if ($id) {
    $s = db()->prepare('SELECT * FROM admin_users WHERE id = ?');
    $s->execute([$id]);
    $m = $s->fetch() ?: null;
    if (!$m) { toast_set('Member not found.', 'error'); redirect('members.php'); }
}
$me = admin_current();
$f = $m ?: ['username'=>'','full_name'=>'','email'=>'','role'=>'admin','status'=>'active','permissions'=>null];
$selPerms = $m && $m['permissions'] ? (json_decode($m['permissions'], true) ?: []) : (ADMIN_ROLES[$f['role']]['perms'] ?? []);
$error = null;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!csrf_verify($_POST['csrf_token'] ?? null)) {
        $error = 'Your session expired. Please try again.';
    } else {
        $username = trim((string) ($_POST['username'] ?? ''));
        $f = ['username'=>$username,'full_name'=>trim((string) ($_POST['full_name'] ?? '')),'email'=>trim((string) ($_POST['email'] ?? '')),
              'role'=>(string) ($_POST['role'] ?? ''),'status'=>(string) ($_POST['status'] ?? 'active'),'permissions'=>null];
        $selPerms = array_values(array_intersect(array_keys(ADMIN_PERMISSIONS), (array) ($_POST['perms'] ?? [])));
        $pw = (string) ($_POST['password'] ?? '');

        if (!isset(ADMIN_ROLES[$f['role']])) { $error = 'Choose a valid role.'; }
        elseif (!preg_match('/^[A-Za-z0-9_.-]{3,40}$/', $username)) { $error = 'Username must be 3–40 letters, numbers, dots, dashes or underscores.'; }
        elseif ($f['email'] !== '' && !filter_var($f['email'], FILTER_VALIDATE_EMAIL)) { $error = 'Please enter a valid email address.'; }
        elseif (!$m && strlen($pw) < 8) { $error = 'New admins need a password of at least 8 characters.'; }
        elseif ($m && $pw !== '' && strlen($pw) < 8) { $error = 'Password must be at least 8 characters.'; }
        elseif (!in_array($f['status'], ['active','inactive'], true)) { $error = 'Invalid status.'; }
        else {
            $dup = db()->prepare('SELECT COUNT(*) FROM admin_users WHERE username = ? AND id <> ?');
            $dup->execute([$username, $id]);
            if ($dup->fetchColumn()) { $error = 'That username is already taken.'; }
        }
        // Protect against locking everyone out / self-demotion
        if (!$error && $m && (int) $m['id'] === (int) $me['id'] && ($f['role'] !== 'super_admin' && $m['role'] === 'super_admin' || $f['status'] !== 'active')) {
            $error = 'You cannot demote or deactivate your own account.';
        }
        if (!$error && $m && $m['role'] === 'super_admin' && ($f['role'] !== 'super_admin' || $f['status'] !== 'active')) {
            $c = (int) db()->query("SELECT COUNT(*) FROM admin_users WHERE role='super_admin' AND status='active'")->fetchColumn();
            if ($c <= 1) { $error = 'There must always be at least one active Super Admin.'; }
        }
        if (!$error) {
            $permJson = $f['role'] === 'super_admin' ? null : json_encode($selPerms);
            if ($m) {
                db()->prepare('UPDATE admin_users SET username=?, full_name=?, email=?, role=?, status=?, permissions=? WHERE id=?')
                    ->execute([$username, $f['full_name'], $f['email'], $f['role'], $f['status'], $permJson, $id]);
                if ($pw !== '') {
                    db()->prepare('UPDATE admin_users SET password_hash=? WHERE id=?')->execute([password_hash($pw, PASSWORD_DEFAULT), $id]);
                }
                admin_log('member_update', 'Edited admin "' . $username . '" (' . $f['role'] . ')');
                toast_set('Admin updated.');
            } else {
                db()->prepare('INSERT INTO admin_users (username, password_hash, full_name, email, role, status, permissions) VALUES (?,?,?,?,?,?,?)')
                    ->execute([$username, password_hash($pw, PASSWORD_DEFAULT), $f['full_name'], $f['email'], $f['role'], $f['status'], $permJson]);
                admin_log('member_create', 'Added admin "' . $username . '" (' . $f['role'] . ')');
                toast_set('Admin added.');
            }
            redirect('members.php');
        }
    }
}

$admin_page_title = $m ? 'Edit Admin' : 'Add Admin';
require_once __DIR__ . '/../includes/admin-header.php';
?>
<h1><?= e($admin_page_title) ?></h1>
<p style="margin-bottom:18px;"><a href="members.php" style="color:var(--terracotta);font-weight:700;">← Back to members</a></p>
<?php if ($error): ?><div class="admin-alert admin-alert-error"><?= e($error) ?></div><?php endif; ?>

<form method="post" class="form-card">
  <input type="hidden" name="csrf_token" value="<?= e(csrf_token()) ?>"><input type="hidden" name="id" value="<?= $id ?>">
  <div class="form-grid">
    <div class="form-row"><label>Username *</label><input name="username" required value="<?= e($f['username']) ?>" autocomplete="off"></div>
    <div class="form-row"><label>Full name</label><input name="full_name" value="<?= e((string) $f['full_name']) ?>"></div>
    <div class="form-row"><label>Email</label><input type="email" name="email" value="<?= e((string) $f['email']) ?>"></div>
    <div class="form-row"><label><?= $m ? 'New password (leave blank to keep)' : 'Password *' ?></label><input type="password" name="password" autocomplete="new-password" <?= $m ? '' : 'required' ?> minlength="8"></div>
    <div class="form-row"><label>Role</label>
      <select name="role" id="roleSel"><?php foreach (ADMIN_ROLES as $k => $r): ?><option value="<?= $k ?>" <?= $f['role'] === $k ? 'selected' : '' ?>><?= e($r['label']) ?></option><?php endforeach; ?></select></div>
    <div class="form-row"><label>Status</label>
      <select name="status"><option value="active" <?= $f['status']==='active'?'selected':'' ?>>Active</option><option value="inactive" <?= $f['status']==='inactive'?'selected':'' ?>>Inactive (cannot log in)</option></select></div>
  </div>
  <div class="form-row">
    <label>Permissions <span style="font-weight:500;color:var(--charcoal-soft);">— picking a role pre-fills these; tick or untick to customise. Super Admin always has everything.</span></label>
    <div class="perm-grid" id="permGrid">
      <?php foreach (ADMIN_PERMISSIONS as $k => $label): ?>
        <label><input type="checkbox" name="perms[]" value="<?= $k ?>" <?= in_array($k, $selPerms, true) ? 'checked' : '' ?>> <?= e($label) ?></label>
      <?php endforeach; ?>
    </div>
  </div>
  <button class="btn btn-primary" type="submit"><?= $m ? 'Save changes' : 'Add admin' ?></button>
</form>
<script>
var ROLE_PERMS = <?= json_encode(array_map(fn($r) => $r['perms'], ADMIN_ROLES)) ?>;
document.getElementById('roleSel').addEventListener('change', function () {
  var p = ROLE_PERMS[this.value] || [], all = p.indexOf('*') > -1;
  document.querySelectorAll('#permGrid input').forEach(function (c) { c.checked = all || p.indexOf(c.value) > -1; });
});
</script>
<?php require_once __DIR__ . '/../includes/admin-footer.php'; ?>
