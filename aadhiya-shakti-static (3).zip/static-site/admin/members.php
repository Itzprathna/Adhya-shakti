<?php
require_once __DIR__ . '/../includes/config.php';
admin_require_login();
admin_require_permission('manage_admins');

$me = admin_current();
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!csrf_verify($_POST['csrf_token'] ?? null)) {
        toast_set('Your session expired. Please try again.', 'error');
        redirect('members.php');
    }
    $id = (int) ($_POST['id'] ?? 0);
    $s = db()->prepare('SELECT * FROM admin_users WHERE id = ?');
    $s->execute([$id]);
    $m = $s->fetch();
    $action = $_POST['action'] ?? '';
    $supers = (int) db()->query("SELECT COUNT(*) FROM admin_users WHERE role='super_admin' AND status='active'")->fetchColumn();

    if (!$m) {
        toast_set('Member not found.', 'error');
    } elseif ($id === (int) $me['id'] && in_array($action, ['toggle', 'delete'], true)) {
        toast_set('You cannot deactivate or delete your own account.', 'error');
    } elseif ($m['role'] === 'super_admin' && $m['status'] === 'active' && $supers <= 1 && in_array($action, ['toggle', 'delete'], true)) {
        toast_set('There must always be at least one active Super Admin.', 'error');
    } elseif ($action === 'toggle') {
        db()->prepare("UPDATE admin_users SET status = IF(status='active','inactive','active') WHERE id = ?")->execute([$id]);
        admin_log('member_status', 'Toggled status of admin "' . $m['username'] . '"');
        toast_set('Status updated for ' . $m['username'] . '.');
    } elseif ($action === 'delete') {
        db()->prepare('DELETE FROM admin_users WHERE id = ?')->execute([$id]);
        admin_log('member_delete', 'Deleted admin "' . $m['username'] . '"');
        toast_set('Admin "' . $m['username'] . '" deleted.');
    } elseif ($action === 'reset') {
        $new = bin2hex(random_bytes(5)) . 'A!';
        db()->prepare('UPDATE admin_users SET password_hash = ? WHERE id = ?')->execute([password_hash($new, PASSWORD_DEFAULT), $id]);
        admin_log('member_reset', 'Reset password for admin "' . $m['username'] . '"');
        toast_set('New password for ' . $m['username'] . ': ' . $new . '  (copy it now — it is not shown again)');
    }
    redirect('members.php');
}

$q = trim((string) ($_GET['q'] ?? ''));
$role = (string) ($_GET['role'] ?? '');
$st = (string) ($_GET['status'] ?? '');
$sql = 'SELECT * FROM admin_users WHERE 1=1';
$args = [];
if ($q !== '') { $sql .= ' AND (username LIKE ? OR full_name LIKE ? OR email LIKE ?)'; array_push($args, "%$q%", "%$q%", "%$q%"); }
if (isset(ADMIN_ROLES[$role])) { $sql .= ' AND role = ?'; $args[] = $role; }
if (in_array($st, ['active', 'inactive'], true)) { $sql .= ' AND status = ?'; $args[] = $st; }
$stmt = db()->prepare($sql . ' ORDER BY id');
$stmt->execute($args);
$rows = $stmt->fetchAll();

$admin_page_title = 'Admin Members';
require_once __DIR__ . '/../includes/admin-header.php';
?>
<div style="display:flex; justify-content:space-between; align-items:center; flex-wrap:wrap; gap:12px;">
  <div><h1>Admin Members</h1><p style="color:var(--charcoal-soft);">Who can log in, and what each person is allowed to do.</p></div>
  <a href="member-edit.php" class="btn btn-primary btn-sm">+ Add Admin</a>
</div>

<form class="filters" method="get">
  <input type="search" name="q" placeholder="Search username, name or email…" value="<?= e($q) ?>">
  <select name="role"><option value="">All roles</option>
    <?php foreach (ADMIN_ROLES as $k => $r): ?><option value="<?= $k ?>" <?= $role === $k ? 'selected' : '' ?>><?= e($r['label']) ?></option><?php endforeach; ?></select>
  <select name="status"><option value="">Any status</option><option value="active" <?= $st==='active'?'selected':'' ?>>Active</option><option value="inactive" <?= $st==='inactive'?'selected':'' ?>>Inactive</option></select>
  <button class="btn btn-outline btn-sm" type="submit">Filter</button>
</form>

<div class="tbl-wrap"><table class="tbl">
  <thead><tr><th>Username</th><th>Name / Email</th><th>Role</th><th>Status</th><th>Created</th><th>Actions</th></tr></thead>
  <tbody>
  <?php foreach ($rows as $r): ?>
    <tr>
      <td><strong><?= e($r['username']) ?></strong><?= (int) $r['id'] === (int) $me['id'] ? ' <span class="badge">you</span>' : '' ?></td>
      <td><?= e((string) $r['full_name']) ?><br><span style="font-size:.78rem;color:var(--charcoal-soft);"><?= e((string) $r['email']) ?></span></td>
      <td><span class="badge"><?= e(ADMIN_ROLES[$r['role']]['label'] ?? $r['role']) ?></span></td>
      <td><span class="badge <?= $r['status']==='active'?'on':'off' ?>"><?= e($r['status']) ?></span></td>
      <td style="font-size:.8rem;"><?= e(substr((string) $r['created_at'], 0, 10)) ?></td>
      <td style="white-space:nowrap;">
        <a class="btn-link" href="member-edit.php?id=<?= $r['id'] ?>">Edit</a>
        <form method="post" style="display:inline;" data-confirm="<?= $r['status']==='active' ? 'Deactivate ' : 'Activate ' ?><?= e($r['username']) ?>?<?= $r['status']==='active' ? ' They will be signed out and unable to log in.' : '' ?>">
          <input type="hidden" name="csrf_token" value="<?= e(csrf_token()) ?>"><input type="hidden" name="id" value="<?= $r['id'] ?>"><input type="hidden" name="action" value="toggle">
          <button class="btn-link" type="submit"><?= $r['status']==='active'?'Deactivate':'Activate' ?></button></form>
        <form method="post" style="display:inline;" data-confirm="Generate a new random password for <?= e($r['username']) ?>?">
          <input type="hidden" name="csrf_token" value="<?= e(csrf_token()) ?>"><input type="hidden" name="id" value="<?= $r['id'] ?>"><input type="hidden" name="action" value="reset">
          <button class="btn-link" type="submit">Reset password</button></form>
        <form method="post" style="display:inline;" data-confirm="Permanently delete admin “<?= e($r['username']) ?>”?">
          <input type="hidden" name="csrf_token" value="<?= e(csrf_token()) ?>"><input type="hidden" name="id" value="<?= $r['id'] ?>"><input type="hidden" name="action" value="delete">
          <button class="btn-link danger" type="submit">Delete</button></form>
      </td>
    </tr>
  <?php endforeach; ?>
  </tbody>
</table></div>
<?php require_once __DIR__ . '/../includes/admin-footer.php'; ?>
