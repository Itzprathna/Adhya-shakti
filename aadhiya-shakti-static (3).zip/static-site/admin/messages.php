<?php
require_once __DIR__ . '/../includes/config.php';
admin_require_login();
admin_require_permission('manage_messages');

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action'])) {
    if (csrf_verify($_POST['csrf_token'] ?? null)) {
        $id = (int) ($_POST['id'] ?? 0);
        if ($_POST['action'] === 'mark_read' && $id > 0) {
            db()->prepare('UPDATE contact_messages SET status = "read" WHERE id = ?')->execute([$id]);
        } elseif ($_POST['action'] === 'archive' && $id > 0) {
            db()->prepare('UPDATE contact_messages SET status = "archived" WHERE id = ?')->execute([$id]);
        } elseif ($_POST['action'] === 'delete' && $id > 0) {
            db()->prepare('DELETE FROM contact_messages WHERE id = ?')->execute([$id]);
        }
    }
    redirect('messages.php' . (!empty($_GET['filter']) ? '?filter=' . urlencode($_GET['filter']) : ''));
}

$filter = $_GET['filter'] ?? 'all';
$allowedFilters = ['all', 'new', 'read', 'archived'];
if (!in_array($filter, $allowedFilters, true)) {
    $filter = 'all';
}

if ($filter === 'all') {
    $stmt = db()->query('SELECT * FROM contact_messages ORDER BY created_at DESC');
} else {
    $stmt = db()->prepare('SELECT * FROM contact_messages WHERE status = ? ORDER BY created_at DESC');
    $stmt->execute([$filter]);
}
$messages = $stmt->fetchAll();

$counts = db()->query('SELECT status, COUNT(*) AS c FROM contact_messages GROUP BY status')->fetchAll(PDO::FETCH_KEY_PAIR);
$totalCount = array_sum($counts);

$admin_page_title = 'Contact Messages';
require_once __DIR__ . '/../includes/admin-header.php';
?>

<div class="admin-stats">
  <div class="admin-stat"><div class="num"><?= (int) $totalCount ?></div><div class="label">Total</div></div>
  <div class="admin-stat"><div class="num"><?= (int) ($counts['new'] ?? 0) ?></div><div class="label">New</div></div>
  <div class="admin-stat"><div class="num"><?= (int) ($counts['read'] ?? 0) ?></div><div class="label">Read</div></div>
  <div class="admin-stat"><div class="num"><?= (int) ($counts['archived'] ?? 0) ?></div><div class="label">Archived</div></div>
</div>

<div style="display:flex; gap:8px; margin-bottom:24px;">
  <?php foreach ($allowedFilters as $f): ?>
    <a href="messages.php?filter=<?= e($f) ?>"
       style="padding:8px 16px; border-radius:100px; font-size:0.85rem; font-weight:600; border:1.5px solid var(--border); <?= $filter === $f ? 'background:var(--ink); color:var(--ivory); border-color:var(--ink);' : 'background:var(--paper); color:var(--charcoal-soft);' ?>">
      <?= ucfirst($f) ?>
    </a>
  <?php endforeach; ?>
</div>

<?php if (empty($messages)): ?>
  <div class="admin-card" style="text-align:center; color:var(--charcoal-soft);">No messages in this view yet.</div>
<?php else: ?>
  <?php foreach ($messages as $msg): ?>
    <div class="admin-card">
      <div style="display:flex; justify-content:space-between; align-items:flex-start; gap:16px; flex-wrap:wrap;">
        <div>
          <strong style="font-size:1.05rem;"><?= e($msg['name']) ?></strong>
          <span style="font-size:0.68rem; font-weight:700; text-transform:uppercase; padding:3px 10px; border-radius:100px; margin-left:8px; background: <?= $msg['status'] === 'new' ? 'var(--peach)' : '#e5e5e5' ?>; color: <?= $msg['status'] === 'new' ? 'var(--terracotta)' : '#555' ?>;"><?= e($msg['status']) ?></span>
          <div style="font-size:0.82rem; color:var(--charcoal-soft); margin-top:4px;">
            <?= e($msg['email']) ?><?= $msg['phone'] ? ' · ' . e($msg['phone']) : '' ?> · <?= e(ucfirst(str_replace('-', ' ', $msg['service']))) ?>
          </div>
        </div>
        <div style="font-size:0.82rem; color:var(--charcoal-soft);"><?= e(date('d M Y, g:i A', strtotime($msg['created_at']))) ?></div>
      </div>
      <p style="margin-top:14px; color:var(--charcoal);"><?= nl2br(e($msg['message'])) ?></p>
      <div style="display:flex; gap:8px; margin-top:14px;">
        <?php if ($msg['status'] !== 'read'): ?>
          <form method="post" action="messages.php?filter=<?= e($filter) ?>">
            <input type="hidden" name="csrf_token" value="<?= e(csrf_token()) ?>">
            <input type="hidden" name="id" value="<?= (int) $msg['id'] ?>">
            <input type="hidden" name="action" value="mark_read">
            <button type="submit" style="font-size:0.78rem; font-weight:700; padding:6px 14px; border-radius:100px; border:1.5px solid var(--border); background:var(--paper); cursor:pointer;">Mark Read</button>
          </form>
        <?php endif; ?>
        <?php if ($msg['status'] !== 'archived'): ?>
          <form method="post" action="messages.php?filter=<?= e($filter) ?>">
            <input type="hidden" name="csrf_token" value="<?= e(csrf_token()) ?>">
            <input type="hidden" name="id" value="<?= (int) $msg['id'] ?>">
            <input type="hidden" name="action" value="archive">
            <button type="submit" style="font-size:0.78rem; font-weight:700; padding:6px 14px; border-radius:100px; border:1.5px solid var(--border); background:var(--paper); cursor:pointer;">Archive</button>
          </form>
        <?php endif; ?>
        <form method="post" action="messages.php?filter=<?= e($filter) ?>" onsubmit="return confirm('Delete this message permanently?');">
          <input type="hidden" name="csrf_token" value="<?= e(csrf_token()) ?>">
          <input type="hidden" name="id" value="<?= (int) $msg['id'] ?>">
          <input type="hidden" name="action" value="delete">
          <button type="submit" style="font-size:0.78rem; font-weight:700; padding:6px 14px; border-radius:100px; border:1.5px solid var(--border); background:var(--paper); cursor:pointer; color:var(--terracotta);">Delete</button>
        </form>
      </div>
    </div>
  <?php endforeach; ?>
<?php endif; ?>

<?php require_once __DIR__ . '/../includes/admin-footer.php'; ?>
