<?php
require_once __DIR__ . '/../includes/config.php';
require_once __DIR__ . '/../includes/data.php';
admin_require_login();
admin_require_permission('manage_tutors');

$id = (int) ($_GET['id'] ?? $_POST['id'] ?? 0);
$tutor = null;
if ($id) {
    $s = db()->prepare('SELECT * FROM tutors WHERE id = ?');
    $s->execute([$id]);
    $tutor = $s->fetch() ?: null;
    if (!$tutor) { toast_set('Tutor not found.', 'error'); redirect('tutors.php'); }
}
$fields = ['name','slug','specialization','category','intro','bio','experience','qualification','email','phone','instagram','youtube','website','status'];
$f = $tutor ?: array_fill_keys($fields, '');
if (!$tutor) { $f['category'] = 'dance'; $f['status'] = 'active'; $f['image'] = ''; }
$error = null;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!csrf_verify($_POST['csrf_token'] ?? null)) {
        $error = 'Your session expired. Please try again.';
    } else {
        foreach ($fields as $k) { $f[$k] = trim((string) ($_POST[$k] ?? '')); }
        $f['slug'] = slugify($f['slug'] !== '' ? $f['slug'] : $f['name']);
        if (!in_array($f['category'], ['dance','singing','choreography'], true)) { $f['category'] = 'dance'; }
        if (!in_array($f['status'], ['active','inactive'], true)) { $f['status'] = 'active'; }

        if ($f['name'] === '' || $f['specialization'] === '') {
            $error = 'Name and specialization are required.';
        } elseif ($f['email'] !== '' && !filter_var($f['email'], FILTER_VALIDATE_EMAIL)) {
            $error = 'Please enter a valid email address.';
        } else {
            $dup = db()->prepare('SELECT COUNT(*) FROM tutors WHERE slug = ? AND id <> ?');
            $dup->execute([$f['slug'], $id]);
            if ($dup->fetchColumn()) { $error = 'Another tutor already uses the slug “' . $f['slug'] . '”.'; }
        }
        $up = ['none' => true];
        if (!$error && isset($_FILES['image']) && $_FILES['image']['error'] !== UPLOAD_ERR_NO_FILE) {
            if (!admin_can('manage_tutor_images')) {
                $error = 'You do not have permission to upload tutor images.';
            } else {
                $up = save_uploaded_image('image', 'tutor');
                if (isset($up['error'])) { $error = $up['error']; }
            }
        }
        if (!$error) {
            $old = $tutor['image'] ?? '';
            $image = !empty($up['path']) ? $up['path'] : $old;
            $vals = [$f['name'],$f['slug'],$f['specialization'],$f['category'],$f['intro'],$f['bio'],$f['experience'],$f['qualification'],$f['email'],$f['phone'],$f['instagram'],$f['youtube'],$f['website'],$image,$f['status']];
            if ($tutor) {
                db()->prepare('UPDATE tutors SET name=?, slug=?, specialization=?, category=?, intro=?, bio=?, experience=?, qualification=?, email=?, phone=?, instagram=?, youtube=?, website=?, image=?, status=? WHERE id=?')
                    ->execute(array_merge($vals, [$id]));
                // Keep course links valid if the slug changed
                if ($f['slug'] !== $tutor['slug']) {
                    db()->prepare('UPDATE courses SET instructor_slug = ? WHERE instructor_slug = ?')->execute([$f['slug'], $tutor['slug']]);
                }
                if (!empty($up['path'])) { delete_uploaded_image($old); }
                admin_log('tutor_update', 'Edited tutor "' . $f['name'] . '"');
                toast_set('Tutor updated.');
            } else {
                db()->prepare('INSERT INTO tutors (name, slug, specialization, category, intro, bio, experience, qualification, email, phone, instagram, youtube, website, image, status) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)')->execute($vals);
                admin_log('tutor_create', 'Added tutor "' . $f['name'] . '"');
                toast_set('Tutor added.');
            }
            redirect('tutors.php');
        }
        $f['image'] = $tutor['image'] ?? '';
    }
}

$admin_page_title = $tutor ? 'Edit Tutor' : 'Add Tutor';
require_once __DIR__ . '/../includes/admin-header.php';
$canImg = admin_can('manage_tutor_images');
?>
<h1><?= e($admin_page_title) ?></h1>
<p style="margin-bottom:18px;"><a href="tutors.php" style="color:var(--terracotta);font-weight:700;">← Back to tutors</a></p>
<?php if ($error): ?><div class="admin-alert admin-alert-error"><?= e($error) ?></div><?php endif; ?>

<form method="post" enctype="multipart/form-data" class="form-card">
  <input type="hidden" name="csrf_token" value="<?= e(csrf_token()) ?>"><input type="hidden" name="id" value="<?= $id ?>">
  <div class="form-row">
    <label>Profile photo <?= $canImg ? '' : '(you cannot change this)' ?></label>
    <div style="display:flex; gap:18px; align-items:center; flex-wrap:wrap;">
      <img id="imgPrev" class="img-preview" style="border-radius:50%;" src="<?= e(admin_img($f['image'] ?? '')) ?>" alt="Preview">
      <div><input type="file" name="image" accept="image/jpeg,image/png,image/webp,image/gif" data-preview="#imgPrev" <?= $canImg ? '' : 'disabled' ?>>
      <p style="font-size:.78rem;color:var(--charcoal-soft);margin-top:6px;">JPG, PNG, WEBP or GIF, up to 5 MB. Choosing a new file replaces the old one.</p></div>
    </div>
  </div>
  <div class="form-grid">
    <div class="form-row"><label>Name *</label><input name="name" required value="<?= e($f['name']) ?>"></div>
    <div class="form-row"><label>URL slug (blank = from name)</label><input name="slug" value="<?= e($f['slug']) ?>"></div>
    <div class="form-row"><label>Specialization *</label><input name="specialization" required value="<?= e($f['specialization']) ?>"></div>
    <div class="form-row"><label>Category</label><select name="category">
      <?php foreach (['dance','singing','choreography'] as $c): ?><option value="<?= $c ?>" <?= $f['category']===$c?'selected':'' ?>><?= ucfirst($c) ?></option><?php endforeach; ?></select></div>
    <div class="form-row"><label>Experience</label><input name="experience" value="<?= e((string) $f['experience']) ?>" placeholder="8 years"></div>
    <div class="form-row"><label>Qualification</label><input name="qualification" value="<?= e((string) $f['qualification']) ?>"></div>
    <div class="form-row"><label>Email</label><input type="email" name="email" value="<?= e((string) $f['email']) ?>"></div>
    <div class="form-row"><label>Phone</label><input name="phone" value="<?= e((string) $f['phone']) ?>"></div>
    <div class="form-row"><label>Instagram</label><input name="instagram" value="<?= e((string) $f['instagram']) ?>"></div>
    <div class="form-row"><label>YouTube</label><input name="youtube" value="<?= e((string) $f['youtube']) ?>"></div>
    <div class="form-row"><label>Website</label><input name="website" value="<?= e((string) $f['website']) ?>"></div>
    <div class="form-row"><label>Status</label><select name="status"><option value="active" <?= $f['status']==='active'?'selected':'' ?>>Active (visible)</option><option value="inactive" <?= $f['status']==='inactive'?'selected':'' ?>>Inactive (hidden)</option></select></div>
  </div>
  <div class="form-row"><label>Short intro</label><input name="intro" maxlength="400" value="<?= e((string) $f['intro']) ?>"></div>
  <div class="form-row"><label>Biography</label><textarea name="bio" rows="5"><?= e((string) $f['bio']) ?></textarea></div>
  <button class="btn btn-primary" type="submit"><?= $tutor ? 'Save changes' : 'Add tutor' ?></button>
</form>
<?php require_once __DIR__ . '/../includes/admin-footer.php'; ?>
