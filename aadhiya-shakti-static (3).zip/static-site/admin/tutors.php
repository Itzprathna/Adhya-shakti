<?php
require_once __DIR__ . '/../includes/config.php';
require_once __DIR__ . '/../includes/data.php';
admin_require_login();
admin_require_permission('manage_tutors');

$pdo = db();
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!csrf_verify($_POST['csrf_token'] ?? null)) {
        toast_set('Your session expired. Please try again.', 'error');
        redirect('tutors.php');
    }
    $id = (int) ($_POST['id'] ?? 0);
    $s = $pdo->prepare('SELECT * FROM tutors WHERE id = ?');
    $s->execute([$id]);
    $t = $s->fetch();
    $action = $_POST['action'] ?? '';
    if (!$t) { toast_set('Tutor not found.', 'error'); redirect('tutors.php'); }

    if ($action === 'toggle') {
        $pdo->prepare("UPDATE tutors SET status = IF(status='active','inactive','active') WHERE id = ?")->execute([$id]);
        admin_log('tutor_status', 'Toggled status of tutor "' . $t['name'] . '"');
        toast_set('Status updated for ' . $t['name'] . '.');
    } elseif ($action === 'delete') {
        $n = $pdo->prepare('SELECT COUNT(*) FROM courses WHERE instructor_slug = ?');
        $n->execute([$t['slug']]);
        $assigned = (int) $n->fetchColumn();
        if ($assigned > 0) {
            // Safe delete: courses must be reassigned (or left with no tutor) first.
            $to = (string) ($_POST['reassign_to'] ?? '__ask__');
            if ($to === '__ask__') { redirect('tutors.php?reassign=' . $id); }
            if ($to === '__none__') {
                $pdo->prepare('UPDATE courses SET instructor_slug = NULL WHERE instructor_slug = ?')->execute([$t['slug']]);
            } else {
                $chk = $pdo->prepare('SELECT COUNT(*) FROM tutors WHERE slug = ? AND id <> ?');
                $chk->execute([$to, $id]);
                if (!$chk->fetchColumn()) { toast_set('Pick a valid tutor to reassign to.', 'error'); redirect('tutors.php?reassign=' . $id); }
                $pdo->prepare('UPDATE courses SET instructor_slug = ? WHERE instructor_slug = ?')->execute([$to, $t['slug']]);
            }
        }
        $pdo->prepare('DELETE FROM tutors WHERE id = ?')->execute([$id]);
        delete_uploaded_image($t['image']);
        admin_log('tutor_delete', 'Deleted tutor "' . $t['name'] . '"' . ($assigned ? " ($assigned courses reassigned)" : ''));
        toast_set('Tutor "' . $t['name'] . '" deleted' . ($assigned ? " and $assigned course(s) reassigned." : '.'));
    }
    redirect('tutors.php');
}

$total = (int) $pdo->query('SELECT COUNT(*) FROM tutors')->fetchColumn();
$q = trim((string) ($_GET['q'] ?? ''));
$cat = (string) ($_GET['cat'] ?? '');
$st = (string) ($_GET['status'] ?? '');
$sql = 'SELECT t.*, (SELECT COUNT(*) FROM courses c WHERE c.instructor_slug = t.slug) AS n FROM tutors t WHERE 1=1';
$args = [];
if ($q !== '') { $sql .= ' AND (t.name LIKE ? OR t.specialization LIKE ?)'; $args[] = "%$q%"; $args[] = "%$q%"; }
if ($cat !== '') { $sql .= ' AND t.category = ?'; $args[] = $cat; }
if (in_array($st, ['active', 'inactive'], true)) { $sql .= ' AND t.status = ?'; $args[] = $st; }
$sql .= ' ORDER BY t.id DESC';
$stmt = $pdo->prepare($sql);
$stmt->execute($args);
$rows = $stmt->fetchAll();

$reassign = null;
if (!empty($_GET['reassign'])) {
    $s = $pdo->prepare('SELECT t.*, (SELECT COUNT(*) FROM courses c WHERE c.instructor_slug = t.slug) AS n FROM tutors t WHERE id = ?');
    $s->execute([(int) $_GET['reassign']]);
    $reassign = $s->fetch() ?: null;
    $others = $pdo->prepare('SELECT slug, name FROM tutors WHERE id <> ? ORDER BY name');
    $others->execute([(int) $_GET['reassign']]);
    $others = $others->fetchAll();
}

$admin_page_title = 'Tutors';
require_once __DIR__ . '/../includes/admin-header.php';
?>
<div style="display:flex; justify-content:space-between; align-items:center; flex-wrap:wrap; gap:12px;">
  <div><h1>Tutors</h1><p style="color:var(--charcoal-soft);"><?= $total ?> total · shown on the public Instructors pages.</p></div>
  <a href="tutor-edit.php" class="btn btn-primary btn-sm">+ Add Tutor</a>
</div>

<?php if ($total === 0): ?>
  <div class="admin-alert admin-alert-error" style="margin-top:18px;">No tutors in the database yet — the site shows the built-in demo profiles. Run <a href="../database/migrate.php" style="text-decoration:underline;">database/migrate.php</a> once to import them.</div>
<?php endif; ?>

<?php if ($reassign): ?>
  <div class="admin-card" style="border:2px solid var(--coral); margin-top:18px;">
    <h3>“<?= e($reassign['name']) ?>” is assigned to <?= (int) $reassign['n'] ?> course(s)</h3>
    <p style="color:var(--charcoal-soft);margin:6px 0 14px;">Choose who should take over those courses before this tutor is deleted.</p>
    <form method="post" data-confirm="Delete <?= e($reassign['name']) ?> and reassign the courses?" style="display:flex;gap:12px;flex-wrap:wrap;align-items:flex-end;">
      <input type="hidden" name="csrf_token" value="<?= e(csrf_token()) ?>"><input type="hidden" name="action" value="delete"><input type="hidden" name="id" value="<?= $reassign['id'] ?>">
      <div class="form-row" style="margin:0;min-width:240px;"><label>Reassign courses to</label>
        <select name="reassign_to">
          <?php foreach ($others as $o): ?><option value="<?= e($o['slug']) ?>"><?= e($o['name']) ?></option><?php endforeach; ?>
          <option value="__none__">No tutor (leave unassigned)</option>
        </select></div>
      <button class="btn btn-danger btn-sm" type="submit">Reassign &amp; delete</button>
      <a class="btn btn-outline btn-sm" href="tutors.php">Cancel</a>
    </form>
  </div>
<?php endif; ?>

<form class="filters" method="get">
  <input type="search" name="q" placeholder="Search name or specialization…" value="<?= e($q) ?>">
  <select name="cat"><option value="">All categories</option>
    <?php foreach (['dance' => 'Dance', 'singing' => 'Singing', 'choreography' => 'Choreography'] as $k => $v): ?><option value="<?= $k ?>" <?= $cat === $k ? 'selected' : '' ?>><?= $v ?></option><?php endforeach; ?>
  </select>
  <select name="status"><option value="">Any status</option><option value="active" <?= $st==='active'?'selected':'' ?>>Active</option><option value="inactive" <?= $st==='inactive'?'selected':'' ?>>Inactive</option></select>
  <button class="btn btn-outline btn-sm" type="submit">Filter</button>
</form>

<div class="tbl-wrap"><table class="tbl">
  <thead><tr><th>Photo</th><th>Tutor</th><th>Category</th><th>Courses</th><th>Status</th><th>Actions</th></tr></thead>
  <tbody>
  <?php foreach ($rows as $r): ?>
    <tr>
      <td><img class="thumb round" src="<?= e(admin_img($r['image'])) ?>" alt=""></td>
      <td><strong><?= e($r['name']) ?></strong><br><span style="font-size:.78rem;color:var(--charcoal-soft);"><?= e($r['specialization']) ?></span></td>
      <td><?= e(ucfirst($r['category'])) ?></td>
      <td><?= (int) $r['n'] ?></td>
      <td><span class="badge <?= $r['status']==='active'?'on':'off' ?>"><?= e($r['status']) ?></span></td>
      <td style="white-space:nowrap;">
        <a class="btn-link" href="tutor-edit.php?id=<?= $r['id'] ?>">Edit</a>
        <form method="post" style="display:inline;"><input type="hidden" name="csrf_token" value="<?= e(csrf_token()) ?>"><input type="hidden" name="id" value="<?= $r['id'] ?>"><input type="hidden" name="action" value="toggle">
          <button class="btn-link" type="submit"><?= $r['status']==='active'?'Deactivate':'Activate' ?></button></form>
        <form method="post" style="display:inline;" data-confirm="Delete tutor “<?= e($r['name']) ?>”?<?= $r['n'] ? ' They teach ' . (int) $r['n'] . ' course(s) — you will choose who takes over next.' : ' This cannot be undone.' ?>">
          <input type="hidden" name="csrf_token" value="<?= e(csrf_token()) ?>"><input type="hidden" name="id" value="<?= $r['id'] ?>"><input type="hidden" name="action" value="delete">
          <button class="btn-link danger" type="submit">Delete</button></form>
      </td>
    </tr>
  <?php endforeach; ?>
  <?php if (!$rows): ?><tr><td colspan="6" style="text-align:center;color:var(--charcoal-soft);padding:30px;">No tutors found.</td></tr><?php endif; ?>
  </tbody>
</table></div>
<?php require_once __DIR__ . '/../includes/admin-footer.php'; ?>
