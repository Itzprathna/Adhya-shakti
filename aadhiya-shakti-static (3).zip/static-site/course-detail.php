<?php
require_once __DIR__ . '/includes/data.php';

$slug   = isset($_GET['course']) ? trim((string) $_GET['course']) : '';
$course = $slug !== '' ? get_course($slug) : null;
$categories = get_categories();

if ($course) {
    $page_title = $course['title'] . ' — Aadhiya Shakti Academy';
    $page_description = $course['excerpt'];
} else {
    $page_title = 'Course Not Found — Aadhiya Shakti Academy';
    $page_description = 'This course could not be found.';
}
require_once __DIR__ . '/includes/header.php';

if (!$course) {
    ?>
    <section class="page-header">
      <div class="container">
        <h1>We couldn't find that course</h1>
        <p>It may have been renamed or the link might be out of date.</p>
        <div style="margin-top:24px;"><a href="courses.php" class="btn btn-primary">Browse All Courses</a></div>
      </div>
    </section>
    <?php
    require_once __DIR__ . '/includes/footer.php';
    exit;
}

$instructor = $course['instructor'] ? get_instructor($course['instructor']) : null;
$tint = $course['category'] === 'dance' ? 'dance' : ($course['category'] === 'singing' ? 'singing' : 'choreo');
$catName = $categories[$course['category']]['name'];
$subName = $categories[$course['category']]['subcategories'][$course['subcategory']] ?? '';

// A few generic FAQs, reused across course pages (content-appropriate,
// not database-driven — just shared static content).
$courseFaqs = [
    ['q' => 'Do I need any prior experience?', 'a' => 'Check the "Level" shown above — most courses marked Beginner assume no prior experience at all.'],
    ['q' => 'Can I try a class before committing?', 'a' => 'Contact the academy directly to ask about trial arrangements for this specific course.'],
    ['q' => 'Is the pricing shown final?', 'a' => 'Pricing shown is ' . strtolower($course['price_note']) . ' — confirm exact pricing and any package options directly with the academy.'],
];
?>

<section class="page-header" style="padding-bottom:0;">
  <div class="container">
    <span class="eyebrow"><?= htmlspecialchars($catName) ?> · <?= htmlspecialchars($subName) ?></span>
    <h1><?= htmlspecialchars($course['title']) ?></h1>
    <p><?= htmlspecialchars($course['excerpt']) ?></p>
  </div>
</section>

<section>
  <div class="container" style="display:grid; grid-template-columns: 1.1fr 0.9fr; gap:48px; align-items:start;">
    <div>
      <div class="img-tint img-tint--<?= $tint ?>" style="aspect-ratio:16/10; margin-bottom:28px;">
        <img src="<?= $course['image'] ?>" alt="<?= htmlspecialchars($course['title']) ?>">
      </div>

      <h2>Course Description</h2>
      <p style="margin:14px 0 28px; color:var(--charcoal-soft);"><?= htmlspecialchars($course['description']) ?></p>

      <h2>What You'll Learn</h2>
      <ul class="service-list" style="margin-top:14px 0 28px;">
        <?php foreach ($course['outcomes'] as $point): ?>
          <li><?= htmlspecialchars($point) ?></li>
        <?php endforeach; ?>
      </ul>

      <h2 style="margin-top:28px;">Frequently Asked Questions</h2>
      <div class="faq-list" style="margin-top:14px;">
        <?php foreach ($courseFaqs as $f): ?>
          <div class="faq-item">
            <button class="faq-question"><?= htmlspecialchars($f['q']) ?><span class="plus">+</span></button>
            <div class="faq-answer"><p><?= htmlspecialchars($f['a']) ?></p></div>
          </div>
        <?php endforeach; ?>
      </div>
    </div>

    <aside style="background:var(--paper); border-radius:var(--radius-lg); padding:28px; box-shadow:var(--shadow-soft); position:sticky; top:96px;">
      <div style="font-family:var(--font-display); font-size:1.9rem; font-weight:700;"><?= htmlspecialchars($course['price']) ?></div>
      <div class="price-note" style="margin-bottom:20px;"><?= htmlspecialchars($course['price_note']) ?></div>

      <div class="course-meta-row" style="flex-direction:column; gap:10px; margin-bottom:20px;">
        <span><strong>Category:</strong> <?= htmlspecialchars($catName) ?></span>
        <span><strong>Subcategory:</strong> <?= htmlspecialchars($subName) ?></span>
        <span><strong>Level:</strong> <?= htmlspecialchars($course['level']) ?></span>
        <span><strong>Duration:</strong> <?= htmlspecialchars($course['duration']) ?></span>
        <span><strong>Mode:</strong> <?= htmlspecialchars($course['mode']) ?></span>
      </div>

      <?php if ($instructor): ?>
        <div style="display:flex; gap:12px; align-items:center; padding:14px 0; border-top:1px solid var(--border); border-bottom:1px solid var(--border); margin-bottom:20px;">
          <div class="img-tint img-tint--<?= $instructor['category'] === 'dance' ? 'dance' : 'singing' ?>" style="width:52px; height:52px; border-radius:50%; flex-shrink:0;">
            <img src="<?= $instructor['image'] ?>" alt="<?= htmlspecialchars($instructor['name']) ?>" style="border-radius:50%;">
          </div>
          <div>
            <strong style="display:block; font-size:0.92rem;"><?= htmlspecialchars($instructor['name']) ?></strong>
            <span style="font-size:0.8rem; color:var(--charcoal-soft);"><?= htmlspecialchars($instructor['specialty']) ?></span>
          </div>
        </div>
      <?php else: ?>
        <p style="font-size:0.85rem; color:var(--charcoal-soft); padding:14px 0; border-top:1px solid var(--border); border-bottom:1px solid var(--border); margin-bottom:20px;">
          This is an event choreography service, coordinated directly by the academy's choreography team rather than a single named instructor.
        </p>
      <?php endif; ?>

      <a href="contact.php" class="btn btn-primary" style="width:100%; justify-content:center;">Contact Academy</a>
    </aside>
  </div>
</section>

<?php require_once __DIR__ . '/includes/footer.php'; ?>
