-- ============================================================================
-- Aadhiya Shakti Academy (static site) — Admin Features
-- Run this AFTER database/schema.sql.
--
-- Three new tables, each supporting one specific admin capability:
--   admin_users       — multiple admin logins (username + password)
--   course_overrides  — lets an admin change a course's price without
--                       touching includes/data.php's static array
--   site_images       — lets an admin upload a replacement photo for
--                       specific spots (category cards, About page) from
--                       their own computer, without editing code
-- ============================================================================

SET NAMES utf8mb4;

-- ----------------------------------------------------------------------------
-- admin_users
-- ----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS admin_users (
  id            INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  username      VARCHAR(60) NOT NULL UNIQUE,
  password_hash VARCHAR(255) NOT NULL,
  created_at    TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- A starter admin account so the panel works immediately after import.
-- Username: admin   Password: ChangeMe123!   — CHANGE THIS (see README.md
-- for how, and how to add further admin accounts).
INSERT INTO admin_users (username, password_hash) VALUES (
  'admin',
  '$2y$10$DPWWH7JwvLMiezCqcsSTbuPSF2eYiTL7ftUH44.v3vRhz.BiDDgQC'
);

-- ----------------------------------------------------------------------------
-- course_overrides
-- One row per course slug the admin has edited. includes/data.php checks
-- this table when building each course and uses these values instead of
-- the static array's price/price_note if a row exists here.
-- ----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS course_overrides (
  course_slug VARCHAR(180) PRIMARY KEY,
  price       VARCHAR(60)  NOT NULL,
  price_note  VARCHAR(30)  NOT NULL,
  updated_at  TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ----------------------------------------------------------------------------
-- site_images
-- One row per named "image slot" (e.g. 'category_dance', 'about_main').
-- includes/data.php and about.php check this table and use the uploaded
-- filename (stored under assets/images/uploads/) instead of the bundled
-- default photo, if a row exists here.
-- ----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS site_images (
  image_key  VARCHAR(60) PRIMARY KEY,
  filename   VARCHAR(255) NOT NULL,
  updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
