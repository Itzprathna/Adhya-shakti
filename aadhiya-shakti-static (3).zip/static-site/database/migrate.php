<?php
/**
 * database/migrate.php — ONE-TIME, safe-to-repeat setup/migration.
 *
 * Open  http://localhost:8888/<your-folder>/database/migrate.php  while logged in
 * to the admin panel (or run `php database/migrate.php` in Terminal).
 *
 * It (1) adds the new admin_users columns (role, status, permissions...),
 * (2) makes every EXISTING admin a Super Admin, (3) copies the built-in
 * categories, courses and demo instructors into the database tables so they
 * can be edited from the admin panel. Nothing is deleted; existing rows are skipped.
 */
require_once __DIR__ . '/../includes/config.php';
require_once __DIR__ . '/../includes/data.php';

$cli = PHP_SAPI === 'cli';
if (!$cli && !admin_is_logged_in()) {
    http_response_code(403);
    exit('Please log in at admin/login.php first, then reload this page.');
}
header('Content-Type: text/plain; charset=utf-8');

$pdo = db();
$log = function (string $m) { echo $m . "\n"; };

// 1. admin_users columns (works on MySQL 5.7/8 and MariaDB)
$cols = [
    'full_name'   => 'VARCHAR(120) NULL',
    'email'       => 'VARCHAR(190) NULL',
    'role'        => "VARCHAR(30) NOT NULL DEFAULT 'super_admin'",
    'status'      => "ENUM('active','inactive') NOT NULL DEFAULT 'active'",
    'permissions' => 'TEXT NULL',
    'last_login'  => 'TIMESTAMP NULL',
];
$have = $pdo->query("SELECT COLUMN_NAME FROM information_schema.COLUMNS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'admin_users'")->fetchAll(PDO::FETCH_COLUMN);
foreach ($cols as $name => $def) {
    if (!in_array($name, $have, true)) {
        $pdo->exec("ALTER TABLE admin_users ADD COLUMN `$name` $def");
        $log("admin_users: added column $name");
    }
}
$pdo->exec("UPDATE admin_users SET role = 'super_admin' WHERE role = '' OR role IS NULL");

// 2. categories + subcategories
$n = 0;
foreach (_get_categories_static() as $slug => $c) {
    $st = $pdo->prepare('SELECT id FROM categories WHERE slug = ?');
    $st->execute([$slug]);
    $cid = $st->fetchColumn();
    if (!$cid) {
        $pdo->prepare('INSERT INTO categories (slug, name, blurb, image, image_key) VALUES (?,?,?,?,?)')
            ->execute([$slug, $c['name'], $c['blurb'], $c['image'], $c['image_key'] ?? null]);
        $cid = (int) $pdo->lastInsertId();
        $n++;
    }
    foreach ($c['subcategories'] as $ss => $sn) {
        $pdo->prepare('INSERT IGNORE INTO subcategories (category_id, slug, name) VALUES (?,?,?)')->execute([$cid, $ss, $sn]);
    }
}
$log("categories: $n new");

// 3. tutors
$n = 0;
foreach (_get_instructors_static() as $slug => $t) {
    $st = $pdo->prepare('SELECT COUNT(*) FROM tutors WHERE slug = ?');
    $st->execute([$slug]);
    if (!$st->fetchColumn()) {
        $pdo->prepare('INSERT INTO tutors (name, slug, specialization, category, intro, bio, image) VALUES (?,?,?,?,?,?,?)')
            ->execute([$t['name'], $slug, $t['specialty'], $t['category'], $t['intro'], $t['bio'], $t['image']]);
        $n++;
    }
}
$log("tutors: $n new");

// 4. courses (price overrides from the old Course Pricing page are applied)
$n = 0;
$over = _get_course_price_overrides();
foreach (_get_courses_static() as $slug => $c) {
    $st = $pdo->prepare('SELECT COUNT(*) FROM courses WHERE slug = ?');
    $st->execute([$slug]);
    if ($st->fetchColumn()) {
        continue;
    }
    $cat = $pdo->prepare('SELECT id FROM categories WHERE slug = ?');
    $cat->execute([$c['category']]);
    $cid = $cat->fetchColumn();
    $sid = null;
    if (!empty($c['subcategory'])) {
        $sc = $pdo->prepare('SELECT id FROM subcategories WHERE category_id = ? AND slug = ?');
        $sc->execute([$cid, $c['subcategory']]);
        $sid = $sc->fetchColumn() ?: null;
    }
    $price = $over[$slug]['price'] ?? $c['price'];
    $note  = $over[$slug]['price_note'] ?? $c['price_note'];
    $pdo->prepare('INSERT INTO courses (category_id, subcategory_id, instructor_slug, title, slug, level, duration, mode, price, price_note, image, excerpt, description, outcomes)
                   VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?)')
        ->execute([$cid, $sid, $c['instructor'] ?: null, $c['title'], $slug, $c['level'], $c['duration'], $c['mode'], $price, $note,
                   $c['image'], $c['excerpt'], $c['description'], implode("\n", $c['outcomes'])]);
    $n++;
}
$log("courses: $n new");
admin_log('migrate', 'Ran database/migrate.php');
$log('Done.');
