-- Tutors, admin roles/permissions, activity log. Run AFTER courses-management.sql.
-- NOTE: the new admin_users columns (role, status, permissions...) are added
-- by database/migrate.php, because MySQL (MAMP) has no "ADD COLUMN IF NOT EXISTS".
SET NAMES utf8mb4;

CREATE TABLE IF NOT EXISTS tutors (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(120) NOT NULL,
  slug VARCHAR(120) NOT NULL UNIQUE,
  specialization VARCHAR(190) NOT NULL DEFAULT '',
  category VARCHAR(80) NOT NULL DEFAULT 'dance',
  intro VARCHAR(400) NULL,
  bio TEXT NULL,
  experience VARCHAR(80) NULL,
  qualification VARCHAR(190) NULL,
  email VARCHAR(190) NULL,
  phone VARCHAR(40) NULL,
  instagram VARCHAR(190) NULL,
  youtube VARCHAR(190) NULL,
  website VARCHAR(190) NULL,
  image VARCHAR(255) NULL,
  status ENUM('active','inactive') NOT NULL DEFAULT 'active',
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;


CREATE TABLE IF NOT EXISTS admin_activity_log (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  admin_id INT UNSIGNED NULL,
  admin_username VARCHAR(60) NOT NULL,
  action VARCHAR(60) NOT NULL,
  description VARCHAR(500) NOT NULL DEFAULT '',
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  KEY idx_log_created (created_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
