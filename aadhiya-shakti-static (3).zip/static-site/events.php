<?php
$page_title = 'Events — Aadhiya Shakti Academy';
$page_description = 'Workshops, recitals, and cultural events at Aadhiya Shakti Academy.';
require_once __DIR__ . '/includes/header.php';
require_once __DIR__ . '/includes/data.php';

$events = get_events();
?>

<section class="page-header">
  <div class="container">
    <span class="eyebrow">What's On</span>
    <h1>Events</h1>
    <p>Sample event types the academy runs — workshops, recitals, and cultural programs. Dates below are placeholders pending confirmation.</p>
  </div>
</section>

<section style="padding-top:0;">
  <div class="container">
    <div class="event-grid">
      <?php foreach ($events as $event): ?>
        <div class="event-card reveal">
          <div class="img-tint img-tint--choreo"><img src="<?= $event['image'] ?>" alt="<?= htmlspecialchars($event['title']) ?>" loading="lazy"></div>
          <div class="event-card-body">
            <span class="event-type"><?= htmlspecialchars($event['type']) ?></span>
            <h3><?= htmlspecialchars($event['title']) ?></h3>
            <p class="event-meta"><?= htmlspecialchars($event['date']) ?> · <?= htmlspecialchars($event['location']) ?></p>
            <p style="font-size:0.9rem; color:var(--charcoal-soft);"><?= htmlspecialchars($event['description']) ?></p>
          </div>
        </div>
      <?php endforeach; ?>
    </div>
  </div>
</section>

<section>
  <div class="container">
    <div class="cta-band">
      <h2>Want the academy at your event?</h2>
      <p>Cultural programs, corporate events, and private celebrations — get in touch to discuss what you have in mind.</p>
      <div class="cta-actions">
        <a href="contact.php" class="btn btn-coral">Discuss Your Event</a>
      </div>
    </div>
  </div>
</section>

<?php require_once __DIR__ . '/includes/footer.php'; ?>
