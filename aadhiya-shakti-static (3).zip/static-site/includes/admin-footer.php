    </div>
  </div>
</div>

<!-- Confirmation dialog (used by every delete / deactivate button) -->
<div class="modal-bg" id="confirm-bg">
  <div class="modal" role="dialog" aria-modal="true">
    <h3 id="confirm-title">Are you sure?</h3>
    <p id="confirm-text" style="color:var(--charcoal-soft); font-size:.92rem;"></p>
    <div class="row">
      <button type="button" class="btn btn-outline btn-sm" id="confirm-no">Cancel</button>
      <button type="button" class="btn btn-danger btn-sm" id="confirm-yes">Confirm</button>
    </div>
  </div>
</div>

<script>
(function () {
  // Sidebar: collapse / expand (remembered), mobile drawer
  var adm = document.getElementById('adm'), side = document.getElementById('adm-side'), scrim = document.getElementById('adm-scrim');
  try { if (localStorage.getItem('admSide') === 'c') adm.classList.add('collapsed'); } catch (e) {}
  document.getElementById('adm-collapse').addEventListener('click', function () {
    var c = adm.classList.toggle('collapsed');
    try { localStorage.setItem('admSide', c ? 'c' : 'e'); } catch (e) {}
  });
  function drawer(open) { side.classList.toggle('open', open); scrim.classList.toggle('show', open); }
  document.getElementById('adm-burger').addEventListener('click', function () { drawer(!side.classList.contains('open')); });
  scrim.addEventListener('click', function () { drawer(false); });
  document.addEventListener('keydown', function (e) { if (e.key === 'Escape') drawer(false); });

  // Toast notifications
  window.showToast = function (msg, type) {
    var d = document.createElement('div');
    d.className = 'toast' + (type === 'error' ? ' error' : '');
    d.textContent = msg;
    document.getElementById('toast-box').appendChild(d);
    setTimeout(function () { d.remove(); }, 4500);
  };
  <?php if (!empty($toast)): ?>showToast(<?= json_encode($toast['m']) ?>, <?= json_encode($toast['t']) ?>);<?php endif; ?>

  // Confirm dialog: any form with data-confirm="message" asks first.
  var bg = document.getElementById('confirm-bg'), pending = null;
  document.addEventListener('submit', function (ev) {
    var f = ev.target, msg = f.getAttribute('data-confirm');
    if (!msg || f.dataset.ok === '1') return;
    ev.preventDefault();
    pending = f;
    document.getElementById('confirm-text').textContent = msg;
    bg.classList.add('open');
  });
  document.getElementById('confirm-no').onclick = function () { bg.classList.remove('open'); pending = null; };
  document.getElementById('confirm-yes').onclick = function () { if (pending) { pending.dataset.ok = '1'; pending.submit(); } };
  bg.addEventListener('click', function (e) { if (e.target === bg) bg.classList.remove('open'); });

  // Live image preview for <input type="file" data-preview="#imgId">
  document.querySelectorAll('input[type=file][data-preview]').forEach(function (inp) {
    inp.addEventListener('change', function () {
      var img = document.querySelector(inp.getAttribute('data-preview'));
      if (img && inp.files && inp.files[0]) img.src = URL.createObjectURL(inp.files[0]);
    });
  });

  // Client-side table search: <input data-table-search="#tableId">
  document.querySelectorAll('input[data-table-search]').forEach(function (inp) {
    inp.addEventListener('input', function () {
      var q = inp.value.toLowerCase();
      document.querySelectorAll(inp.getAttribute('data-table-search') + ' tbody tr').forEach(function (tr) {
        tr.style.display = tr.textContent.toLowerCase().indexOf(q) > -1 ? '' : 'none';
      });
    });
  });
})();
</script>
</body>
</html>
