<?php
/**
 * includes/admin-header.php — responsive sidebar layout for every admin page.
 * Pages set $admin_page_title first, and call admin_require_login().
 * Menu entries are hidden when the admin lacks that permission (the pages
 * themselves ALSO enforce it on the server — hiding is only cosmetic).
 */
$admin_page_title   = $admin_page_title ?? 'Admin';
$admin_current_file = basename($_SERVER['SCRIPT_NAME']);
$admin              = admin_current();
$roleLabel          = ADMIN_ROLES[$admin['role'] ?? '']['label'] ?? 'Admin';
$toast              = toast_get();
$newMsgBadge        = 0;
try { if (admin_can('manage_messages')) { $newMsgBadge = (int) db()->query("SELECT COUNT(*) FROM contact_messages WHERE status='new'")->fetchColumn(); } } catch (Throwable $ex) {}

$ICONS = ['index.php' => '<path d="M3 11l9-8 9 8v9a1 1 0 0 1-1 1h-5v-6H9v6H4a1 1 0 0 1-1-1z"/>', 'courses.php' => '<path d="M4 5a2 2 0 0 1 2-2h13v16H6a2 2 0 0 0-2 2z"/><path d="M4 19V5"/>', 'categories.php' => '<rect x="3" y="3" width="7" height="7" rx="1.5"/><rect x="14" y="3" width="7" height="7" rx="1.5"/><rect x="3" y="14" width="7" height="7" rx="1.5"/><rect x="14" y="14" width="7" height="7" rx="1.5"/>', 'tutors.php' => '<circle cx="12" cy="8" r="4"/><path d="M4 21a8 8 0 0 1 16 0"/>', 'messages.php' => '<rect x="3" y="5" width="18" height="14" rx="2"/><path d="M3 7l9 6 9-6"/>', 'media.php' => '<rect x="3" y="4" width="18" height="16" rx="2"/><circle cx="9" cy="10" r="2"/><path d="M21 16l-5-5-8 8"/>', 'members.php' => '<circle cx="9" cy="8" r="3.5"/><path d="M2 20a7 7 0 0 1 14 0"/><path d="M16 4.5a3.5 3.5 0 0 1 0 7M22 20a7 7 0 0 0-4-6.3"/>', 'activity.php' => '<path d="M3 12h4l3-8 4 16 3-8h4"/>', 'change-password.php' => '<rect x="4" y="11" width="16" height="10" rx="2"/><path d="M8 11V7a4 4 0 0 1 8 0v4"/>'];
$svg = fn(string $d) => '<svg class="ico" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">' . $d . '</svg>';
$menu = [
    ['index.php',           'Dashboard',       null,                ['index.php']],
    ['courses.php',         'Courses',         'manage_courses',    ['courses.php', 'course-edit.php']],
    ['categories.php',      'Categories',      'manage_categories', ['categories.php']],
    ['tutors.php',          'Tutors',          'manage_tutors',     ['tutors.php', 'tutor-edit.php']],
    ['messages.php',        'Messages',        'manage_messages',   ['messages.php']],
    ['media.php',           'Site Photos',     'manage_photos',     ['media.php']],
    ['members.php',         'Admin Members',   'manage_admins',     ['members.php', 'member-edit.php']],
    ['activity.php',        'Activity Log',    'manage_admins',     ['activity.php']],
    ['change-password.php', 'My Password',     null,                ['change-password.php']],
];
?>
<!doctype html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title><?= e($admin_page_title) ?> — Admin — <?= e(SITE_NAME) ?></title>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link href="https://fonts.googleapis.com/css2?family=Fraunces:opsz,wght@9..144,600;9..144,700&family=Manrope:wght@400;500;600;700&display=swap" rel="stylesheet">
<link rel="stylesheet" href="../assets/css/style.css">
<link rel="icon" type="image/png" href="../assets/images/logo.png">
<style>
  body { background: var(--ivory); }
  /* ---------- Sidebar (Phase 1) ---------- */
  :root { --side-w: 256px; --side-w-sm: 76px; --ease: cubic-bezier(.4,0,.2,1); }
  .adm { display:flex; min-height:100vh; }
  .adm-side { width:var(--side-w); background:linear-gradient(180deg,#3d1530 0%,var(--ink) 55%,#2a0f22 100%); color:var(--ivory); padding:18px 12px; position:sticky; top:0; height:100vh; overflow-x:hidden; overflow-y:auto; flex-shrink:0; display:flex; flex-direction:column; transition:width .35s var(--ease), box-shadow .35s var(--ease); z-index:50; scrollbar-width:none; }
  .adm-side::-webkit-scrollbar { display:none; }
  .adm-brand { display:flex; align-items:center; gap:10px; padding:2px 6px 16px; border-bottom:1px solid rgba(255,235,184,.15); margin-bottom:14px; font-family:var(--font-display); font-weight:700; white-space:nowrap; min-height:56px; }
  .adm-brand img { width:34px; height:34px; object-fit:contain; flex-shrink:0; }
  .adm-collapse { margin-left:auto; flex-shrink:0; width:30px; height:30px; border-radius:50%; border:1px solid rgba(255,235,184,.3); background:rgba(255,235,184,.06); color:var(--ivory); display:grid; place-items:center; transition:transform .35s var(--ease), background .25s; padding:0; }
  .adm-collapse:hover { background:var(--coral); }
  .adm-collapse svg { width:16px; height:16px; }
  .adm-side nav { flex:1; }
  .adm-side nav a, .adm-logout { position:relative; display:flex; align-items:center; gap:14px; padding:11px 14px; border-radius:14px; font-size:.9rem; font-weight:600; color:rgba(255,235,184,.82); margin-bottom:4px; white-space:nowrap; transform-origin:left center; transition:transform .25s var(--ease), background .25s var(--ease), box-shadow .25s var(--ease), color .2s; will-change:transform; }
  .ico { width:22px; height:22px; flex-shrink:0; }
  .lbl { transition:opacity .25s var(--ease); overflow:hidden; text-overflow:ellipsis; }
  .adm-side nav a:hover, .adm-logout:hover { background:rgba(234,157,157,.16); color:#fff; transform:scale(1.045); box-shadow:0 8px 20px rgba(0,0,0,.28); }
  .adm-side nav a.active { background:linear-gradient(135deg,var(--coral),#d46f8d); color:#fff; box-shadow:0 8px 20px rgba(189,85,121,.4); }
  .adm-side nav a.active:hover { transform:scale(1.045); }
  .adm-user { padding:14px 4px 0; border-top:1px solid rgba(255,235,184,.15); font-size:.8rem; color:rgba(255,235,184,.75); }
  .adm-user .who { padding:0 10px 8px; display:flex; flex-direction:column; white-space:nowrap; overflow:hidden; }
  .adm-user .who strong { color:#fff; }
  .adm-logout { color:var(--peach); margin-bottom:0; }

  /* Collapsed (icons only). Hovering the rail glides it open as a flyout. */
  .adm.collapsed .adm-side { width:var(--side-w-sm); }
  .adm.collapsed .adm-side .lbl { opacity:0; }
  .adm.collapsed .adm-side .who { opacity:0; transition:opacity .2s; }
  .adm.collapsed .adm-side:hover .who { opacity:1; transition-delay:.12s; }
  .adm.collapsed .adm-collapse { transform:rotate(180deg); margin-left:-4px; }
  .adm.collapsed .adm-brand img { display:none; }
  .adm.collapsed .adm-brand { justify-content:center; }
  .adm.collapsed .adm-collapse { margin-left:0; }
  .adm.collapsed .adm-side:hover { width:var(--side-w); box-shadow:12px 0 40px rgba(53,20,42,.35); }
  .adm.collapsed .adm-side:hover .lbl { opacity:1; transition-delay:.12s; }
  .adm.collapsed .adm-side:hover .adm-brand img { display:block; }
  .adm.collapsed .adm-side:hover .adm-brand { justify-content:flex-start; }
  .adm.collapsed .adm-side:hover .adm-collapse { margin-left:auto; }
  .adm-main { flex:1; min-width:0; }
  .adm-top { display:none; background:var(--ink); color:var(--ivory); padding:12px 16px; align-items:center; justify-content:space-between; position:sticky; top:0; z-index:40; }
  .adm-top button { background:none; border:1px solid rgba(255,235,184,.4); color:var(--ivory); border-radius:8px; padding:6px 12px; font-size:1.1rem; }
  .adm-content { padding:30px 28px 60px; max-width:1180px; }
  .adm-content h1 { font-size:1.6rem; margin-bottom:4px; }
  .admin-stats { display:grid; grid-template-columns:repeat(auto-fill,minmax(170px,1fr)); gap:14px; margin:24px 0; }
  .admin-stat { background:var(--paper); border-radius:var(--radius-md); padding:18px 22px; box-shadow:var(--shadow-soft); border-left:5px solid var(--coral); }
  .admin-stat .num { font-family:var(--font-display); font-size:1.9rem; font-weight:700; }
  .admin-stat .label { font-size:.78rem; color:var(--charcoal-soft); text-transform:uppercase; letter-spacing:.04em; }
  .admin-card { background:var(--paper); border-radius:var(--radius-md); padding:22px; box-shadow:var(--shadow-soft); margin-bottom:16px; }
  .admin-alert { padding:14px 18px; border-radius:var(--radius-md); margin-bottom:20px; font-weight:600; font-size:.9rem; }
  .admin-alert-success { background:#e3f3e6; color:#1e6b32; }
  .admin-alert-error { background:var(--peach); color:var(--terracotta); }
  .tbl-wrap { overflow-x:auto; background:var(--paper); border-radius:var(--radius-md); box-shadow:var(--shadow-soft); }
  table.tbl { width:100%; border-collapse:collapse; font-size:.88rem; }
  .tbl th { text-align:left; padding:12px 14px; background:rgba(96,29,73,.06); font-size:.74rem; text-transform:uppercase; letter-spacing:.05em; color:var(--charcoal-soft); white-space:nowrap; }
  .tbl td { padding:12px 14px; border-top:1px solid var(--border); vertical-align:middle; }
  .tbl img.thumb { width:48px; height:48px; object-fit:cover; border-radius:10px; }
  .tbl img.thumb.round { border-radius:50%; }
  .badge { display:inline-block; font-size:.72rem; font-weight:700; padding:3px 10px; border-radius:100px; background:var(--peach); color:var(--terracotta); }
  .badge.on { background:#e3f3e6; color:#1e6b32; }
  .badge.off { background:#eee; color:#777; }
  .filters { display:flex; gap:10px; flex-wrap:wrap; margin:18px 0; }
  .filters input, .filters select { padding:10px 14px; border:1.5px solid var(--border); border-radius:10px; font-family:inherit; font-size:.88rem; background:#fff; }
  .filters input[type=search] { flex:1; min-width:180px; }
  .btn-danger { background:#b3261e; color:#fff; border-color:#b3261e; }
  .btn-danger:hover { background:#8f1d17; transform:translateY(-2px); }
  .btn-link { background:none; border:none; color:var(--terracotta); font-weight:700; font-size:.85rem; padding:4px 6px; cursor:pointer; }
  .btn-link.danger { color:#b3261e; }
  .form-grid { display:grid; grid-template-columns:repeat(auto-fit,minmax(240px,1fr)); gap:0 18px; }
  .img-preview { width:140px; height:140px; object-fit:cover; border-radius:14px; border:2px dashed var(--border); background:#fff; }
  .perm-grid { display:grid; grid-template-columns:repeat(auto-fit,minmax(260px,1fr)); gap:8px; }
  .perm-grid label { display:flex; gap:8px; align-items:center; font-size:.88rem; font-weight:600; }
  .perm-grid input { width:auto; }
  /* confirm modal */
  .modal-bg { position:fixed; inset:0; background:rgba(53,20,42,.55); display:none; align-items:center; justify-content:center; z-index:100; padding:20px; }
  .modal-bg.open { display:flex; }
  .modal { background:#fff; border-radius:16px; padding:26px; max-width:440px; width:100%; box-shadow:var(--shadow-soft); }
  .modal h3 { margin-bottom:8px; }
  .modal .row { display:flex; gap:10px; justify-content:flex-end; margin-top:20px; flex-wrap:wrap; }
  /* toast */
  #toast-box { position:fixed; top:18px; right:18px; z-index:200; display:flex; flex-direction:column; gap:10px; }
  .toast { background:#1e6b32; color:#fff; padding:13px 20px; border-radius:12px; font-weight:600; font-size:.9rem; box-shadow:var(--shadow-soft); animation:tin .3s ease; }
  .toast.error { background:#b3261e; }
  @keyframes tin { from { opacity:0; transform:translateY(-10px); } to { opacity:1; transform:none; } }

  /* ---------- Modernised content area ---------- */
  .adm-content h1 { font-size:1.75rem; letter-spacing:-.01em; }
  .adm-content { animation:pgin .45s var(--ease) both; }
  @keyframes pgin { from { opacity:0; transform:translateY(10px); } to { opacity:1; transform:none; } }
  .admin-stats { grid-template-columns:repeat(auto-fill,minmax(165px,1fr)); }
  .admin-stat { position:relative; overflow:hidden; border-left:0; display:flex; gap:14px; align-items:center; transition:transform .25s var(--ease), box-shadow .25s var(--ease); }
  .admin-stat:hover { transform:translateY(-4px); box-shadow:0 18px 38px rgba(96,29,73,.2); }
  .admin-stat .sico { width:46px; height:46px; border-radius:14px; display:grid; place-items:center; background:linear-gradient(135deg,var(--terracotta),var(--coral)); color:#fff; flex-shrink:0; }
  .admin-stat .sico svg { width:22px; height:22px; }
  .admin-stat .label { margin-top:2px; }
  .qgrid { display:grid; grid-template-columns:repeat(auto-fit,minmax(200px,1fr)); gap:14px; margin-bottom:22px; }
  .qcard { background:var(--paper); border-radius:var(--radius-md); padding:16px 18px; display:flex; gap:12px; align-items:center; font-weight:700; font-size:.9rem; box-shadow:var(--shadow-soft); transition:transform .25s var(--ease), background .25s, color .25s; }
  .qcard:hover { transform:translateY(-3px); background:var(--ink); color:var(--ivory); }
  .qcard .plus { width:34px; height:34px; border-radius:50%; background:var(--peach); color:var(--terracotta); display:grid; place-items:center; font-size:1.2rem; transition:background .25s; }
  .qcard:hover .plus { background:var(--coral); color:#fff; }
  .dash-cols { display:grid; grid-template-columns:3fr 2fr; gap:18px; align-items:start; }
  @media (max-width:1000px) { .dash-cols { grid-template-columns:1fr; } }
  .bar-row { display:grid; grid-template-columns:120px 1fr 34px; gap:10px; align-items:center; margin:10px 0; font-size:.85rem; font-weight:600; }
  .bar { height:12px; background:rgba(96,29,73,.08); border-radius:100px; overflow:hidden; }
  .bar i { display:block; height:100%; width:0; border-radius:100px; background:linear-gradient(90deg,var(--terracotta),var(--coral),var(--peach)); transition:width 1s var(--ease); }
  .nav-badge { margin-left:auto; background:var(--peach); color:var(--terracotta); border-radius:100px; font-size:.7rem; font-weight:800; padding:2px 8px; }
  .adm.collapsed .adm-side:not(:hover) .nav-badge { position:absolute; top:6px; right:8px; margin:0; padding:1px 6px; }
  /* tables */
  .tbl-wrap { border-radius:var(--radius-lg); overflow:auto; max-height:72vh; }
  .tbl th { position:sticky; top:0; background:#f7e6df; z-index:1; }
  .tbl tbody tr { transition:background .2s; }
  .tbl tbody tr:nth-child(even) { background:rgba(255,235,184,.22); }
  .tbl tbody tr:hover { background:rgba(234,157,157,.22); }
  .tbl td .btn-link { border-radius:100px; padding:5px 12px; background:rgba(96,29,73,.07); margin:1px 2px; transition:background .2s, color .2s, transform .2s; }
  .tbl td .btn-link:hover { background:var(--terracotta); color:#fff; transform:translateY(-1px); }
  .tbl td .btn-link.danger { background:rgba(179,38,30,.08); }
  .tbl td .btn-link.danger:hover { background:#b3261e; color:#fff; }
  .tbl img.thumb { transition:transform .25s var(--ease); }
  .tbl tr:hover img.thumb { transform:scale(1.12); }
  .filters { background:var(--paper); padding:12px; border-radius:var(--radius-md); box-shadow:var(--shadow-soft); }
  .filters input:focus, .filters select:focus { outline:none; border-color:var(--coral); box-shadow:0 0 0 4px rgba(189,85,121,.18); }
  /* forms */
  .form-card { border-top:5px solid var(--coral); }
  .form-row input, .form-row select, .form-row textarea { transition:border-color .2s, box-shadow .2s; }
  .form-row input:focus, .form-row select:focus, .form-row textarea:focus { box-shadow:0 0 0 4px rgba(189,85,121,.18); }
  .form-row label { color:var(--terracotta); }
  .img-preview { transition:transform .3s var(--ease), border-color .3s; }
  .img-preview:hover { transform:scale(1.04); border-color:var(--coral); }
  .perm-grid label { background:var(--ivory); padding:10px 12px; border-radius:10px; transition:background .2s; }
  .perm-grid label:hover { background:var(--peach); }
  .badge { letter-spacing:.02em; }
  .toast { border-left:5px solid var(--ivory); }
  @media (max-width: 860px) {
    .adm { display:block; }
    .adm-top { display:flex; }
    .adm-side { position:fixed; left:0; top:0; transform:translateX(-105%); transition:transform .35s var(--ease); width:260px !important; }
    .adm-side.open { transform:none; box-shadow:12px 0 40px rgba(53,20,42,.4); }
    .adm.collapsed .adm-side .lbl { opacity:1; }
    .adm.collapsed .adm-brand img { display:block; }
    .adm-collapse { display:none; }
    .adm-scrim { position:fixed; inset:0; background:rgba(53,20,42,.5); opacity:0; pointer-events:none; transition:opacity .3s; z-index:45; }
    .adm-scrim.show { opacity:1; pointer-events:auto; }
    .adm-content { padding:20px 16px 50px; }
  }
  @media (prefers-reduced-motion: reduce) { .adm-side, .adm-side * { transition:none !important; } }
</style>
</head>
<body>
<div id="toast-box"></div>
<div class="adm-scrim" id="adm-scrim"></div>

<div class="adm<?= "" ?>" id="adm">
  <aside class="adm-side" id="adm-side">
    <div class="adm-brand">
      <img src="../assets/images/logo.png" alt="">
      <span class="lbl">Aadhiya Shakti</span>
      <button type="button" class="adm-collapse" id="adm-collapse" aria-label="Collapse or expand sidebar" title="Collapse / expand">
        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M15 6l-6 6 6 6"/></svg>
      </button>
    </div>
    <nav>
      <?php foreach ($menu as [$file, $label, $perm, $match]): ?>
        <?php if ($perm === null || admin_can($perm)): ?>
          <a href="<?= e($file) ?>" class="<?= in_array($admin_current_file, $match, true) ? 'active' : '' ?>" data-tip="<?= e($label) ?>"><?= $svg($ICONS[$file]) ?><span class="lbl"><?= e($label) ?></span><?php if ($file === 'messages.php' && $newMsgBadge > 0): ?><span class="nav-badge"><?= $newMsgBadge ?></span><?php endif; ?></a>
        <?php endif; ?>
      <?php endforeach; ?>
      <a href="../index.php" target="_blank" rel="noopener" data-tip="View Public Site"><?= $svg('<path d="M14 4h6v6"/><path d="M10 14L20 4"/><path d="M19 14v5a1 1 0 0 1-1 1H5a1 1 0 0 1-1-1V6a1 1 0 0 1 1-1h5"/>') ?><span class="lbl">View Public Site</span></a>
    </nav>
    <div class="adm-user">
      <div class="who"><strong><?= e($admin['username'] ?? '') ?></strong><span class="lbl"><?= e($roleLabel) ?></span></div>
      <a href="logout.php" class="adm-logout" data-tip="Logout"><?= $svg('<path d="M9 21H5a1 1 0 0 1-1-1V4a1 1 0 0 1 1-1h4"/><path d="M16 17l5-5-5-5"/><path d="M21 12H9"/>') ?><span class="lbl">Logout</span></a>
    </div>
  </aside>

  <div class="adm-main">
    <div class="adm-top"><strong><?= e($admin_page_title) ?></strong><button type="button" id="adm-burger" aria-label="Menu">☰</button></div>
    <div class="adm-content">
