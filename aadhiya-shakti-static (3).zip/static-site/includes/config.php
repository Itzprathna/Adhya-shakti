<?php
/**
 * includes/config.php
 *
 * This file is NEW — the rest of this site is still static/database-free.
 * It exists solely to support two things: storing Contact page
 * submissions in MySQL, and a password-protected admin page to view them.
 * No other page on the site requires this file.
 */

declare(strict_types=1);

// ---- Site settings -------------------------------------------------------
define('SITE_NAME', 'Aadhiya Shakti Academy');

// SITE_URL auto-detects the request's own host and folder, so it works
// wherever this project happens to be placed (MAMP htdocs subfolder,
// a different port, etc.) without editing this file.
$__protocol  = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') ? 'https' : 'http';
$__host      = $_SERVER['HTTP_HOST'] ?? 'localhost';
$__base_path = rtrim(str_replace('\\', '/', dirname($_SERVER['SCRIPT_NAME'] ?? '')), '/');
define('SITE_URL', $__protocol . '://' . $__host . $__base_path);

// ---- Environment -----------------------------------------------------
define('APP_DEBUG', true); // set false before any real deployment

if (APP_DEBUG) {
    ini_set('display_errors', '1');
    error_reporting(E_ALL);
} else {
    ini_set('display_errors', '0');
    error_reporting(0);
}

// ---- Database (MySQL via PDO) --------------------------------------------
// Defaults match MAMP's bundled MySQL (root/root on port 8889). Update
// these four values if your setup differs — see README.md for the full
// step-by-step MAMP walkthrough.
define('DB_HOST', '127.0.0.1');
define('DB_PORT', 8889);
define('DB_NAME', 'aadhiya_shakti_site');
define('DB_USER', 'root');
define('DB_PASS', 'root');

/**
 * Returns a shared PDO connection, connecting only on first use.
 */
function db(): PDO
{
    static $pdo = null;

    if ($pdo === null) {
        try {
            $pdo = new PDO(
                'mysql:host=' . DB_HOST . ';port=' . DB_PORT . ';dbname=' . DB_NAME . ';charset=utf8mb4',
                DB_USER,
                DB_PASS,
                [
                    PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
                    PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
                    PDO::ATTR_EMULATE_PREPARES   => false,
                ]
            );
        } catch (PDOException $e) {
            if (APP_DEBUG) {
                die('Database connection failed: ' . $e->getMessage());
            }
            die('We are unable to process your request right now. Please try again shortly.');
        }
    }

    return $pdo;
}

/** Escape output for safe HTML rendering (XSS protection). */
function e(string $value): string
{
    return htmlspecialchars($value, ENT_QUOTES, 'UTF-8');
}

/** Redirect and stop execution. */
function redirect(string $path): void
{
    header('Location: ' . $path);
    exit;
}

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

/** Generates/returns a per-session CSRF token. */
function csrf_token(): string
{
    if (empty($_SESSION['csrf_token'])) {
        $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
    }
    return $_SESSION['csrf_token'];
}

/** Verifies a submitted CSRF token against the session's token. */
function csrf_verify(?string $token): bool
{
    return is_string($token) && !empty($_SESSION['csrf_token']) && hash_equals($_SESSION['csrf_token'], $token);
}

// ---- Admin authentication --------------------------------------------
// Admin accounts now live in the admin_users table (see
// database/admin-features.sql), so more than one person can have their
// own login. See README.md for how to add an admin account or change a
// password.

function admin_is_logged_in(): bool
{
    return !empty($_SESSION['admin_user_id']);
}

function admin_require_login(): void
{
    if (!admin_is_logged_in()) {
        redirect('login.php');
    }
    // Re-check on every request that the account is still active, so
    // deactivating an admin takes effect immediately (even mid-session).
    static $checked = false;
    if (!$checked) {
        $checked = true;
        try {
            $stmt = db()->prepare('SELECT status FROM admin_users WHERE id = ?');
            $stmt->execute([$_SESSION['admin_user_id']]);
            $status = $stmt->fetchColumn();
        } catch (Throwable $ex) {
            $status = 'active'; // status column not migrated yet
        }
        if ($status === false || $status !== 'active') {
            $_SESSION = [];
            session_destroy();
            redirect('login.php');
        }
    }
}

/**
 * Checks a username/password against admin_users. Returns the admin's
 * row (without password_hash) on success, or null on failure / inactive.
 */
function admin_attempt_login(string $username, string $password): ?array
{
    $stmt = db()->prepare('SELECT * FROM admin_users WHERE username = ? LIMIT 1');
    $stmt->execute([$username]);
    $admin = $stmt->fetch();

    if (!$admin || !password_verify($password, $admin['password_hash'])) {
        return null;
    }
    if (isset($admin['status']) && $admin['status'] !== 'active') {
        return null;
    }

    session_regenerate_id(true);
    $_SESSION['admin_user_id']  = $admin['id'];
    $_SESSION['admin_username'] = $admin['username'];
    $_SESSION['admin_role']     = $admin['role'] ?? 'super_admin';
    admin_log('login', 'Logged in.');

    unset($admin['password_hash']);
    return $admin;
}

/** The currently logged-in admin's id/username/role, or null. */
function admin_current(): ?array
{
    if (empty($_SESSION['admin_user_id'])) {
        return null;
    }
    return [
        'id'       => $_SESSION['admin_user_id'],
        'username' => $_SESSION['admin_username'] ?? '',
        'role'     => $_SESSION['admin_role'] ?? 'super_admin',
    ];
}

// ---- Roles & permissions -------------------------------------------------
const ADMIN_PERMISSIONS = [
    'manage_courses'       => 'Manage courses (add / edit / delete)',
    'manage_course_images' => 'Upload / replace course images',
    'manage_tutors'        => 'Manage tutors (add / edit / delete)',
    'manage_tutor_images'  => 'Upload / replace tutor images',
    'manage_categories'    => 'Manage categories & subcategories',
    'manage_photos'        => 'Manage site photos',
    'manage_messages'      => 'View & manage contact messages',
    'manage_admins'        => 'Manage admin members & roles',
];

const ADMIN_ROLES = [
    'super_admin'     => ['label' => 'Super Admin',     'perms' => ['*']],
    'admin'           => ['label' => 'Admin',           'perms' => ['manage_courses','manage_course_images','manage_tutors','manage_tutor_images','manage_categories','manage_photos','manage_messages']],
    'content_manager' => ['label' => 'Content Manager', 'perms' => ['manage_photos','manage_course_images','manage_tutor_images','manage_messages']],
    'course_manager'  => ['label' => 'Course Manager',  'perms' => ['manage_courses','manage_course_images','manage_categories']],
    'tutor_manager'   => ['label' => 'Tutor Manager',   'perms' => ['manage_tutors','manage_tutor_images']],
];

/**
 * True if the logged-in admin holds the permission. Super Admin always does.
 * Everyone else needs it in their saved per-account permission list (which
 * the Members form pre-fills from the role but lets you customise).
 */
function admin_can(string $permission): bool
{
    static $cache = null;
    if (!admin_is_logged_in()) {
        return false;
    }
    if (($_SESSION['admin_role'] ?? '') === 'super_admin') {
        return true;
    }
    if ($cache === null) {
        $cache = [];
        try {
            $stmt = db()->prepare('SELECT role, permissions FROM admin_users WHERE id = ?');
            $stmt->execute([$_SESSION['admin_user_id']]);
            $row = $stmt->fetch();
            if ($row) {
                if ($row['role'] === 'super_admin') {
                    $cache = array_keys(ADMIN_PERMISSIONS);
                } else {
                    $saved = json_decode((string) $row['permissions'], true);
                    $cache = is_array($saved) ? $saved : (ADMIN_ROLES[$row['role']]['perms'] ?? []);
                }
            }
        } catch (Throwable $ex) {
            $cache = [];
        }
    }
    return in_array($permission, $cache, true);
}

/** Stops the request with a 403 page if the admin lacks the permission. */
function admin_require_permission(string $permission): void
{
    if (admin_can($permission)) {
        return;
    }
    http_response_code(403);
    $admin_page_title = 'Access Denied';
    require_once __DIR__ . '/admin-header.php';
    echo '<div class="admin-card"><h2>Access denied</h2><p style="margin-top:8px;color:var(--charcoal-soft);">Your role does not have permission to do this ('
        . e($permission) . '). Ask a Super Admin to update your access.</p>'
        . '<a class="btn btn-primary btn-sm" style="margin-top:16px;" href="index.php">Back to dashboard</a></div>';
    require_once __DIR__ . '/admin-footer.php';
    exit;
}

/** Best-effort activity log entry; never breaks the page if it fails. */
function admin_log(string $action, string $description = ''): void
{
    try {
        $stmt = db()->prepare('INSERT INTO admin_activity_log (admin_id, admin_username, action, description) VALUES (?, ?, ?, ?)');
        $stmt->execute([
            $_SESSION['admin_user_id'] ?? null,
            $_SESSION['admin_username'] ?? 'system',
            $action,
            mb_substr($description, 0, 500),
        ]);
    } catch (Throwable $ex) {
        // Log table not created yet — ignore.
    }
}

// ---- Image upload helper -------------------------------------------------
/**
 * Validates and saves an uploaded image from $_FILES[$field].
 * Returns ['path' => 'assets/images/uploads/x.jpg'] on success,
 * ['none' => true] if no file was chosen, or ['error' => '...'].
 * Checks real image content (not the filename), max 5 MB, random filename.
 */
function save_uploaded_image(string $field, string $prefix): array
{
    $file = $_FILES[$field] ?? null;
    if (!$file || ($file['error'] ?? UPLOAD_ERR_NO_FILE) === UPLOAD_ERR_NO_FILE) {
        return ['none' => true];
    }
    if ($file['error'] !== UPLOAD_ERR_OK) {
        return ['error' => 'The upload failed (error code ' . (int) $file['error'] . '). Try a smaller file.'];
    }
    if ($file['size'] > 5 * 1024 * 1024) {
        return ['error' => 'Image is larger than 5 MB.'];
    }
    $info  = @getimagesize($file['tmp_name']);
    $types = [IMAGETYPE_JPEG => 'jpg', IMAGETYPE_PNG => 'png', IMAGETYPE_WEBP => 'webp', IMAGETYPE_GIF => 'gif'];
    if ($info === false || !isset($types[$info[2]])) {
        return ['error' => 'That file is not a valid image (JPG, PNG, WEBP or GIF only).'];
    }
    $name = preg_replace('/[^a-z0-9-]/', '', strtolower($prefix)) . '-' . bin2hex(random_bytes(6)) . '.' . $types[$info[2]];
    $dir  = __DIR__ . '/../assets/images/uploads/';
    if (!is_dir($dir)) {
        mkdir($dir, 0755, true);
    }
    if (!move_uploaded_file($file['tmp_name'], $dir . $name)) {
        return ['error' => 'Could not save the uploaded file.'];
    }
    return ['path' => 'assets/images/uploads/' . $name];
}

/** Deletes a previously uploaded file (only inside the uploads folder). */
function delete_uploaded_image(?string $path): void
{
    if ($path && strpos($path, 'assets/images/uploads/') === 0 && basename($path) !== '.gitkeep') {
        $full = __DIR__ . '/../' . $path;
        if (is_file($full)) {
            @unlink($full);
        }
    }
}

/** URL for showing an image path inside admin pages (they live one folder deep). */
function admin_img(?string $path): string
{
    if (!$path) {
        return '../assets/images/logo.png';
    }
    return preg_match('#^https?://#', $path) ? $path : '../' . $path;
}

function slugify(string $text): string
{
    $text = strtolower(trim(preg_replace('/[^A-Za-z0-9]+/', '-', $text), '-'));
    return $text !== '' ? $text : 'item';
}

// ---- Toast notifications (shown once after a redirect) -------------------
function toast_set(string $message, string $type = 'success'): void
{
    $_SESSION['toast'] = ['m' => $message, 't' => $type];
}
function toast_get(): ?array
{
    $t = $_SESSION['toast'] ?? null;
    unset($_SESSION['toast']);
    return $t;
}
