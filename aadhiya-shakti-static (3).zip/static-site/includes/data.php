<?php
/**
 * includes/data.php
 *
 * ALL website content lives here as plain PHP arrays. There is no
 * database, no PDO, no MySQL anywhere in this file — every page that
 * uses this file gets its content from plain PHP arrays. (The one
 * exception on this site is contact.php, which uses includes/config.php
 * separately to store form submissions — this file is unrelated to that.)
 * simply reads from these arrays. To add or edit a course, instructor,
 * testimonial, etc., edit the arrays below directly.
 */

declare(strict_types=1);

// ---------------------------------------------------------------------------
// Image pool
// A small set of verified, freely-licensed Unsplash photos (Unsplash
// License — free for commercial use, no attribution required), reused
// across sections with different color-tint overlays (applied in CSS via
// .img-tint--dance / --singing / --choreo / --studio) so repeated images
// read as an intentional art-directed palette rather than accidental
// duplication. Swap any of these for real academy photography whenever
// it's available — see README.md.
// ---------------------------------------------------------------------------
define('IMG_DANCE',     'https://images.unsplash.com/photo-1479813183133-f2e9b38ed6c4?auto=format&fit=crop&w=1400&q=80');   // Kathak dancer mid-performance
define('IMG_SINGING',   'https://images.unsplash.com/photo-1763567712690-8a7a7f9e373b?auto=format&fit=crop&w=1400&q=80');   // Vocalist singing into a microphone
define('IMG_STUDIO',    'https://images.unsplash.com/photo-1756314355464-96764066ed21?auto=format&fit=crop&w=1400&q=80');   // Dancers rehearsing in a studio
define('IMG_FESTIVAL',  'https://images.unsplash.com/photo-1624234636182-6d61fe4cd140?auto=format&fit=crop&w=1400&q=80');   // Costumed dancer, festival/night setting

// Additional unique images reserved for instructor profiles specifically,
// so no two instructors share a photo (each is a distinct, verified
// Unsplash-License photo).
define('IMG_INS_1', 'https://images.unsplash.com/photo-1533993010187-6a08e5a05ec9?auto=format&fit=crop&w=800&q=80'); // Dancer mid-leap
define('IMG_INS_2', 'https://images.unsplash.com/photo-1589146343010-b0eb86d21155?auto=format&fit=crop&w=800&q=80'); // Ballet silhouette jump
define('IMG_INS_3', 'https://images.unsplash.com/photo-1730875647697-eace28e2a77e?auto=format&fit=crop&w=800&q=80'); // Singer on stage with microphone
define('IMG_INS_4', 'https://images.unsplash.com/photo-1763964062626-063ceec3100a?auto=format&fit=crop&w=800&q=80'); // Singer playing guitar on stage
define('IMG_INS_5', 'https://images.unsplash.com/photo-1767376133991-a3306ad0817f?auto=format&fit=crop&w=800&q=80'); // Singer performing passionately
define('IMG_INS_6', 'https://images.unsplash.com/photo-1662397699540-533dd886809d?auto=format&fit=crop&w=800&q=80'); // Stringed instrument close-up

// ---------------------------------------------------------------------------
// Real, locally-hosted photos (user-provided, Pexels-licensed — free for
// commercial use). Bundled directly in assets/images/gallery/ rather than
// hotlinked, since these are actual project assets, not stock placeholders.
// ---------------------------------------------------------------------------
define('IMG_STUDIO_BAND',      'assets/images/gallery/studio-band.jpg');          // Two women rehearsing: vocalist/guitarist + drummer
define('IMG_MARCHING_BAND',    'assets/images/gallery/marching-band.jpg');        // Large marching band in red/white uniforms
define('IMG_CONCERT_CROWD',    'assets/images/gallery/concert-crowd.jpg');        // Crowd at a lit concert, hands raised
define('IMG_FESTIVAL_STAGE',   'assets/images/gallery/festival-stage.jpg');       // Festival stage lighting rig, crowd in front
define('IMG_GUITAR_CLOSEUP',   'assets/images/gallery/guitar-closeup.jpg');       // Close-up of an electric guitar being played
define('IMG_MANIPURI_1',       'assets/images/gallery/manipuri-dancer-1.jpg');    // Manipuri-style classical dancer, pose 1
define('IMG_MANIPURI_2',       'assets/images/gallery/manipuri-dancer-2.jpg');    // Manipuri-style classical dancer, pose 2
define('IMG_BIRTHDAY_PARTY',   'assets/images/gallery/birthday-party.jpg');       // Birthday celebration with cake and guests
define('IMG_BAND_PERFORMANCE', 'assets/images/gallery/band-performance.jpg');     // Four-piece band performing on a small stage
define('IMG_BHARATANATYAM',    'assets/images/gallery/bharatanatyam-dramatic.jpg'); // Dramatic solo Bharatanatyam pose
define('IMG_KATHAKALI',        'assets/images/gallery/kathakali-group.jpg');      // Kathakali dancers in full costume
define('IMG_KATHAKALI_2', 'https://images.unsplash.com/photo-1741387793505-b4383d221324?auto=format&fit=crop&w=1200&q=80'); // Kathakali close-up
define('IMG_KATHAKALI_3', 'https://images.unsplash.com/photo-1691075221845-687ff5614e66?auto=format&fit=crop&w=1200&q=80'); // Kathakali performer
define('IMG_KATHAKALI_4', 'https://images.unsplash.com/photo-1729079004970-df864ed944ea?auto=format&fit=crop&w=1200&q=80'); // Kathakali makeup & costume

// ---------------------------------------------------------------------------
// Categories & subcategories
// ---------------------------------------------------------------------------
function _get_categories_static(): array
{
    return [
        'dance' => [
            'name'  => 'Dance',
            'slug'  => 'dance',
            'blurb' => 'From classical Bharatanatyam and Kathak to Bollywood and contemporary movement — structured training for every age and level.',
            'image' => IMG_KATHAKALI,
            'image_key' => 'category_dance',
            'subcategories' => [
                'classical'    => 'Classical Dance',
                'folk'         => 'Folk Dance',
                'garba'        => 'Garba / Regional Dance',
                'bollywood'    => 'Bollywood Dance',
                'contemporary' => 'Contemporary Dance',
                'wedding'      => 'Wedding Dance',
                'group'        => 'Group Dance',
                'school'       => 'School Dance',
                'kids'         => 'Kids Dance',
                'competition'  => 'Competition Dance',
                'stage'        => 'Stage Performance',
            ],
        ],
        'singing' => [
            'name'  => 'Singing',
            'slug'  => 'singing',
            'blurb' => 'Classical, folk, devotional and contemporary vocal training built on breath control, pitch accuracy, and stage confidence.',
            'image' => IMG_STUDIO_BAND,
            'image_key' => 'category_singing',
            'subcategories' => [
                'classical'  => 'Classical Singing',
                'folk'       => 'Folk Singing',
                'bollywood'  => 'Bollywood Singing',
                'group'      => 'Group Singing',
                'patriotic'  => 'Patriotic Singing',
                'devotional' => 'Devotional Singing',
                'kids'       => 'Kids Singing',
                'vocal'      => 'Vocal Training',
            ],
        ],
        'choreography' => [
            'name'  => 'Choreography',
            'slug'  => 'choreography',
            'blurb' => 'Two paths: learn choreography as a structured course, or hire the academy\'s team to choreograph and stage your event.',
            'image' => IMG_MARCHING_BAND,
            'image_key' => 'category_choreography',
            'subcategories' => [
                'learn'      => 'Learn Choreography',
                'wedding'    => 'Wedding Choreography',
                'school'     => 'School Function',
                'college'    => 'College Function',
                'party'      => 'Party Function',
                'office'     => 'Office Function',
                'corporate'  => 'Corporate Events',
                'cultural'   => 'Cultural Function',
                'annual'     => 'Annual Function',
                'private'    => 'Private Function',
            ],
        ],
    ];
}

/**
 * Fetches any admin-uploaded image overrides from the database.
 * Returns an empty array (never throws) if the database isn't reachable.
 * Maps image_key (e.g. 'category_dance') => local file path to use instead
 * of the bundled default photo.
 */
function _get_site_image_overrides(): array
{
    static $overrides = null;
    if ($overrides !== null) {
        return $overrides;
    }
    $overrides = [];
    try {
        require_once __DIR__ . '/config.php';
        $rows = db()->query('SELECT image_key, filename FROM site_images')->fetchAll();
        foreach ($rows as $row) {
            $overrides[$row['image_key']] = 'assets/images/uploads/' . $row['filename'];
        }
    } catch (Throwable $e) {
        // Database not configured/reachable — fall back to bundled photos.
    }
    return $overrides;
}

/** All categories, with any admin-uploaded photo applied in place of the default. */
function get_categories(): array
{
    $categories = _get_categories_from_db() ?? _get_categories_static();
    $overrides  = _get_site_image_overrides();

    foreach ($categories as $slug => &$cat) {
        if (isset($cat['image_key'], $overrides[$cat['image_key']])) {
            $cat['image'] = $overrides[$cat['image_key']];
        }
    }
    unset($cat);

    return $categories;
}

/**
 * Looks up a single overridable image by its key (e.g. 'about_main'),
 * returning the admin-uploaded photo if one exists, or the given default
 * if not (or if the database isn't reachable).
 */
function get_site_image(string $key, string $default): string
{
    $overrides = _get_site_image_overrides();
    return $overrides[$key] ?? $default;
}

/**
 * Categories from the admin-managed tables, in the SAME shape as the static
 * array. Returns null (so the static data is used) if the tables are empty
 * or the database isn't reachable.
 */
function _get_categories_from_db(): ?array
{
    static $cache = false;
    if ($cache !== false) {
        return $cache;
    }
    $cache = null;
    try {
        require_once __DIR__ . '/config.php';
        $cats = db()->query('SELECT * FROM categories ORDER BY id')->fetchAll();
        if (!$cats) {
            return $cache;
        }
        $out = [];
        foreach ($cats as $c) {
            $out[$c['slug']] = [
                'name' => $c['name'], 'slug' => $c['slug'], 'blurb' => (string) $c['blurb'],
                'image' => $c['image'] ?: IMG_KATHAKALI, 'image_key' => $c['image_key'] ?: 'category_' . $c['slug'],
                'subcategories' => [], '_id' => (int) $c['id'],
            ];
        }
        $byId = array_column($cats, 'slug', 'id');
        foreach (db()->query('SELECT * FROM subcategories ORDER BY id')->fetchAll() as $sc) {
            if (isset($byId[$sc['category_id']])) {
                $out[$byId[$sc['category_id']]]['subcategories'][$sc['slug']] = $sc['name'];
            }
        }
        $cache = $out;
    } catch (Throwable $e) {
        // fall back to static
    }
    return $cache;
}

function get_category(string $slug): ?array
{
    $cats = get_categories();
    return $cats[$slug] ?? null;
}


// ---------------------------------------------------------------------------
// Courses
// 'mode': 'Online', 'In-Studio', 'Online + In-Studio', or 'On-Location'
// 'price_note': "Sample Pricing" or "Starting From" per the pricing
// transparency requirement — nothing here is presented as verified real
// pricing.
//
// PRICE OVERRIDES: an admin can change a course's price via
// admin/courses.php without editing this file. Those changes live in the
// course_overrides database table and are merged in by get_courses() /
// get_course() below. If the database isn't reachable for any reason,
// the site falls back to the prices written directly in this array —
// the public pages never crash just because MySQL isn't configured.
// ---------------------------------------------------------------------------
function _get_courses_static(): array
{
    return [

        // ---------------- DANCE ----------------
        'classical-dance-foundation' => [
            'title' => 'Classical Dance Foundation', 'category' => 'dance', 'subcategory' => 'classical',
            'instructor' => 'dr-kavya-nair', 'level' => 'Beginner', 'duration' => '12 Weeks',
            'mode' => 'Online + In-Studio', 'price' => '₹2,499/month', 'price_note' => 'Sample Pricing',
            'image' => IMG_BHARATANATYAM,
            'excerpt' => 'Foundational Bharatanatyam adavus, posture, and rhythm for complete beginners.',
            'description' => 'A structured entry point into Bharatanatyam, this course builds the postural discipline, footwork, and rhythmic sense that everything else in classical dance is built on. No prior experience needed.',
            'outcomes' => ['Correct posture (aramandi) and basic adavus', 'Hand gestures (hastas) and their meanings', 'Rhythm counting with nattuvangam', 'Your first short performance piece'],
        ],
        'kathak-foundations' => [
            'title' => 'Kathak Foundations', 'category' => 'dance', 'subcategory' => 'classical',
            'instructor' => 'meera-iyer', 'level' => 'Beginner', 'duration' => '12 Weeks',
            'mode' => 'In-Studio', 'price' => '₹2,499/month', 'price_note' => 'Sample Pricing',
            'image' => IMG_DANCE,
            'excerpt' => 'Footwork, spins (chakkars), and storytelling gesture from the Kathak tradition.',
            'description' => 'Kathak\'s intricate footwork and spins take time to build safely — this course paces that development while introducing the storytelling (abhinaya) side of the form from early on.',
            'outcomes' => ['Basic tatkar (footwork) patterns', 'Controlled single and double chakkars', 'Introductory hand gestures and expression', 'A short thumri-based performance piece'],
        ],
        'folk-dance-essentials' => [
            'title' => 'Folk Dance Essentials', 'category' => 'dance', 'subcategory' => 'folk',
            'instructor' => 'ananya-rao', 'level' => 'Beginner', 'duration' => '8 Weeks',
            'mode' => 'In-Studio', 'price' => '₹1,999/month', 'price_note' => 'Sample Pricing',
            'image' => IMG_KATHAKALI,
            'excerpt' => 'Regional folk forms taught with attention to their cultural context, not just steps.',
            'description' => 'A rotating survey of regional folk dance styles, taught with the cultural and rhythmic context behind each form rather than steps in isolation.',
            'outcomes' => ['Core folk footwork across 2–3 regional styles', 'Group formation and spacing', 'Rhythmic clapping and prop work (dandiya sticks, etc.)', 'A group folk performance piece'],
        ],
        'garba-regional-dance' => [
            'title' => 'Garba & Regional Dance', 'category' => 'dance', 'subcategory' => 'garba',
            'instructor' => 'ananya-rao', 'level' => 'All Levels', 'duration' => '6 Weeks (seasonal)',
            'mode' => 'In-Studio', 'price' => '₹1,799/month', 'price_note' => 'Sample Pricing',
            'image' => IMG_MANIPURI_1,
            'excerpt' => 'Garba and dandiya technique ahead of Navratri, for total beginners and returners alike.',
            'description' => 'A seasonal course timed around Navratri, covering traditional garba circles and dandiya (stick) work at a pace that welcomes complete beginners.',
            'outcomes' => ['Basic garba circle footwork', 'Dandiya raas partner technique', 'Building stamina for extended play', 'Confidence dancing in a group setting'],
        ],
        'bollywood-dance-basics' => [
            'title' => 'Bollywood Dance Basics', 'category' => 'dance', 'subcategory' => 'bollywood',
            'instructor' => 'royan-mehta', 'level' => 'Beginner', 'duration' => '8 Weeks',
            'mode' => 'Online + In-Studio', 'price' => '₹1,999/month', 'price_note' => 'Sample Pricing',
            'image' => IMG_STUDIO,
            'excerpt' => 'Fun, high-energy Bollywood choreography drawn from current and classic film numbers.',
            'description' => 'A fitness-friendly, high-energy course with no prior dance experience required — built around full choreography routines to popular film songs.',
            'outcomes' => ['Bollywood dance vocabulary and isolations', 'Two to three full choreography routines per term', 'Expression and camera-ready performance energy', 'Basic freestyle confidence'],
        ],
        'contemporary-movement' => [
            'title' => 'Contemporary Movement', 'category' => 'dance', 'subcategory' => 'contemporary',
            'instructor' => 'royan-mehta', 'level' => 'Intermediate', 'duration' => '10 Weeks',
            'mode' => 'In-Studio', 'price' => '₹2,999/month', 'price_note' => 'Sample Pricing',
            'image' => IMG_STUDIO,
            'excerpt' => 'Contemporary technique building on floorwork, control, and improvisation.',
            'description' => 'For students with some dance background who want to develop a more contemporary movement vocabulary — floorwork, weight-sharing, and structured improvisation.',
            'outcomes' => ['Floorwork and controlled falls', 'Improvisation frameworks', 'Partnering and weight-sharing basics', 'An original short movement piece'],
        ],
        'wedding-dance-training' => [
            'title' => 'Wedding Dance Training', 'category' => 'dance', 'subcategory' => 'wedding',
            'instructor' => 'royan-mehta', 'level' => 'All Levels', 'duration' => '4 Weeks',
            'mode' => 'In-Studio', 'price' => '₹3,499 (couple package)', 'price_note' => 'Sample Pricing',
            'image' => IMG_STUDIO,
            'excerpt' => 'A short, focused course for couples or wedding parties preparing a sangeet performance.',
            'description' => 'Designed for couples, bridal parties, or families preparing a performance for their own wedding sangeet — a compact, deadline-driven course rather than an ongoing program.',
            'outcomes' => ['A complete choreographed routine to your chosen song', 'Basic partner lifts/holds (where appropriate)', 'Confidence performing in front of a crowd', 'A run-through rehearsal close to the event date'],
        ],
        'group-dance-performance' => [
            'title' => 'Group Dance Performance', 'category' => 'dance', 'subcategory' => 'group',
            'instructor' => 'ananya-rao', 'level' => 'Intermediate', 'duration' => '10 Weeks',
            'mode' => 'In-Studio', 'price' => '₹2,499/month', 'price_note' => 'Sample Pricing',
            'image' => IMG_STUDIO,
            'excerpt' => 'Ensemble choreography focused on synchronisation, formations, and stage spacing.',
            'description' => 'Built for students who already have foundational technique and want to work specifically on the group skills — synchronisation, formation changes, spacing — that solo classes don\'t cover.',
            'outcomes' => ['Synchronised group timing', 'Formation transitions', 'Stage spacing and blocking awareness', 'A full ensemble performance piece'],
        ],
        'school-dance-program' => [
            'title' => 'School Dance Program', 'category' => 'dance', 'subcategory' => 'school',
            'instructor' => 'meera-iyer', 'level' => 'Beginner (Ages 8–14)', 'duration' => '12 Weeks',
            'mode' => 'In-Studio', 'price' => '₹1,499/month', 'price_note' => 'Sample Pricing',
            'image' => IMG_DANCE,
            'excerpt' => 'An age-appropriate structured program for school-age children new to dance.',
            'description' => 'A gentler-paced program specifically structured for school-age beginners, balancing technique fundamentals with confidence-building and fun.',
            'outcomes' => ['Basic posture and coordination', 'Simple choreography sequences', 'Comfort performing in front of others', 'A term-end recital piece'],
        ],
        'kids-dance-fundamentals' => [
            'title' => 'Kids Dance Fundamentals', 'category' => 'dance', 'subcategory' => 'kids',
            'instructor' => 'dr-kavya-nair', 'level' => 'Kids (Ages 5–10)', 'duration' => '12 Weeks',
            'mode' => 'In-Studio', 'price' => '₹1,499/month', 'price_note' => 'Sample Pricing',
            'image' => IMG_DANCE,
            'excerpt' => 'A playful introduction to movement, rhythm, and body awareness for young children.',
            'description' => 'Focused on movement literacy rather than technique drilling — young children build rhythm, coordination, and comfort with performing through games and simple sequences.',
            'outcomes' => ['Basic rhythm and movement games', 'Simple sequences and spatial awareness', 'Following group instructions', 'A short, low-pressure showcase'],
        ],
        'competition-dance-training' => [
            'title' => 'Competition Dance Training', 'category' => 'dance', 'subcategory' => 'competition',
            'instructor' => 'royan-mehta', 'level' => 'Advanced', 'duration' => '16 Weeks',
            'mode' => 'In-Studio', 'price' => '₹3,999/month', 'price_note' => 'Sample Pricing',
            'image' => IMG_STUDIO,
            'excerpt' => 'Intensive preparation for students competing in dance competitions or eisteddfods.',
            'description' => 'A demanding, performance-focused track for advanced students actively preparing for competitions — heavier rehearsal load and individualised choreography feedback.',
            'outcomes' => ['Competition-ready choreography', 'Performance polish and consistency under pressure', 'Costume and staging considerations', 'Mock-competition run-throughs'],
        ],
        'stage-performance-training-dance' => [
            'title' => 'Stage Performance Training', 'category' => 'dance', 'subcategory' => 'stage',
            'instructor' => 'meera-iyer', 'level' => 'Advanced', 'duration' => '8 Weeks',
            'mode' => 'In-Studio', 'price' => '₹2,999/month', 'price_note' => 'Sample Pricing',
            'image' => IMG_MANIPURI_2,
            'excerpt' => 'Refining performance quality, expression, and stage presence for advanced dancers.',
            'description' => 'For technically strong dancers who want to sharpen what happens beyond the steps — projection, expression, and command of a stage.',
            'outcomes' => ['Stage presence and projection', 'Working with lighting and spacing cues', 'Expression (abhinaya/emotive) refinement', 'A polished solo performance piece'],
        ],

        // ---------------- SINGING ----------------
        'classical-vocal-foundation' => [
            'title' => 'Classical Vocal Foundation', 'category' => 'singing', 'subcategory' => 'classical',
            'instructor' => 'nikhil-bansal', 'level' => 'Beginner', 'duration' => '12 Weeks',
            'mode' => 'Online + In-Studio', 'price' => '₹2,299/month', 'price_note' => 'Sample Pricing',
            'image' => IMG_SINGING,
            'excerpt' => 'Swara, shruti, and taal fundamentals for students new to classical vocal training.',
            'description' => 'Starts from breath control and swara (note) practice and builds toward singing a first short bandish — the essential groundwork most classical vocal training assumes you already have.',
            'outcomes' => ['Breath control and voice culture', 'Swara and shruti awareness', 'Basic taal (rhythm cycle) counting', 'A short first bandish'],
        ],
        'folk-singing-essentials' => [
            'title' => 'Folk Singing Essentials', 'category' => 'singing', 'subcategory' => 'folk',
            'instructor' => 'priyanka-sethi', 'level' => 'Beginner', 'duration' => '8 Weeks',
            'mode' => 'In-Studio', 'price' => '₹1,899/month', 'price_note' => 'Sample Pricing',
            'image' => IMG_SINGING,
            'excerpt' => 'Regional folk singing styles and their characteristic ornamentation and rhythm.',
            'description' => 'Covers a rotating selection of regional folk singing traditions, with attention to the ornamentation and call-and-response patterns that distinguish folk styles from classical ones.',
            'outcomes' => ['Folk ornamentation techniques', 'Call-and-response singing', 'Regional rhythm patterns', 'A group folk song performance'],
        ],
        'bollywood-vocal-training' => [
            'title' => 'Bollywood Vocal Training', 'category' => 'singing', 'subcategory' => 'bollywood',
            'instructor' => 'arnav-chatterjee', 'level' => 'Beginner–Intermediate', 'duration' => '10 Weeks',
            'mode' => 'Online + In-Studio', 'price' => '₹2,199/month', 'price_note' => 'Sample Pricing',
            'image' => IMG_GUITAR_CLOSEUP,
            'excerpt' => 'Pitch accuracy, breath support, and phrasing for popular film-song singing.',
            'description' => 'Built for students who want to sing contemporary Bollywood songs confidently, with real attention to pitch accuracy and breath support rather than just mimicking a recording.',
            'outcomes' => ['Pitch accuracy and ear training', 'Breath support for sustained phrases', 'Microphone technique basics', 'A performance-ready song repertoire'],
        ],
        'group-singing-workshop' => [
            'title' => 'Group Singing Workshop', 'category' => 'singing', 'subcategory' => 'group',
            'instructor' => 'akash-gupta', 'level' => 'All Levels', 'duration' => '6 Weeks',
            'mode' => 'In-Studio', 'price' => '₹1,699/month', 'price_note' => 'Sample Pricing',
            'image' => IMG_BAND_PERFORMANCE,
            'excerpt' => 'Harmony, blending, and choral discipline for singing as an ensemble.',
            'description' => 'A workshop-style course focused specifically on the skills solo lessons don\'t cover: blending your voice with others, harmony parts, and choral discipline.',
            'outcomes' => ['Basic harmony singing', 'Vocal blending within a group', 'Choral discipline and cueing', 'A group performance piece'],
        ],
        'patriotic-singing-program' => [
            'title' => 'Patriotic Singing Program', 'category' => 'singing', 'subcategory' => 'patriotic',
            'instructor' => 'priyanka-sethi', 'level' => 'All Levels', 'duration' => '4 Weeks (seasonal)',
            'mode' => 'In-Studio', 'price' => '₹1,499 (flat)', 'price_note' => 'Sample Pricing',
            'image' => IMG_SINGING,
            'excerpt' => 'A short seasonal program preparing patriotic songs for school and community events.',
            'description' => 'Timed around national observances, this short program prepares students to perform patriotic songs at school assemblies or community events.',
            'outcomes' => ['Clear diction and projection', 'Group timing for ensemble singing', 'Stage discipline for formal events', 'A rehearsed set for a specific occasion'],
        ],
        'devotional-singing' => [
            'title' => 'Devotional Singing', 'category' => 'singing', 'subcategory' => 'devotional',
            'instructor' => 'nikhil-bansal', 'level' => 'All Levels', 'duration' => '8 Weeks',
            'mode' => 'In-Studio', 'price' => '₹1,899/month', 'price_note' => 'Sample Pricing',
            'image' => IMG_SINGING,
            'excerpt' => 'Bhajans and devotional repertoire, with attention to mood and simple melodic structure.',
            'description' => 'Focused on devotional repertoire (bhajans and related forms), where the goal is emotional sincerity and melodic clarity rather than technical complexity.',
            'outcomes' => ['Common devotional ragas and structures', 'Simple harmonium accompaniment basics', 'Group call-and-response bhajan singing', 'A devotional set for a gathering or event'],
        ],
        'kids-vocal-basics' => [
            'title' => 'Kids Vocal Basics', 'category' => 'singing', 'subcategory' => 'kids',
            'instructor' => 'vidya-krishnan', 'level' => 'Kids (Ages 6–12)', 'duration' => '12 Weeks',
            'mode' => 'In-Studio', 'price' => '₹1,499/month', 'price_note' => 'Sample Pricing',
            'image' => IMG_SINGING,
            'excerpt' => 'A gentle, playful introduction to pitch, breath, and confident singing for children.',
            'description' => 'Introduces young children to singing through games and simple songs, prioritising comfort and enjoyment while gently building pitch awareness.',
            'outcomes' => ['Basic pitch matching', 'Simple breath control exercises', 'Comfort singing solo and in a group', 'A short, low-pressure showcase'],
        ],
        'stage-singing-preparation' => [
            'title' => 'Stage Singing Preparation', 'category' => 'singing', 'subcategory' => 'vocal',
            'instructor' => 'devansh-oberoi', 'level' => 'Intermediate–Advanced', 'duration' => '8 Weeks',
            'mode' => 'In-Studio', 'price' => '₹2,499/month', 'price_note' => 'Sample Pricing',
            'image' => IMG_SINGING,
            'excerpt' => 'Microphone technique, stage presence, and performance polish for public singing.',
            'description' => 'For students who already sing well and want to close the gap between "singing in a lesson" and "performing on a stage" — mic technique, nerves, and presence.',
            'outcomes' => ['Microphone technique and positioning', 'Managing performance nerves', 'Stage presence and audience connection', 'A polished performance set'],
        ],
        'vocal-training-general' => [
            'title' => 'Vocal Training', 'category' => 'singing', 'subcategory' => 'vocal',
            'instructor' => 'akash-gupta', 'level' => 'All Levels', 'duration' => 'Ongoing',
            'mode' => 'Online + In-Studio', 'price' => '₹1,999/month', 'price_note' => 'Sample Pricing',
            'image' => IMG_SINGING,
            'excerpt' => 'General ongoing vocal training and riyaz (practice) discipline, style-flexible.',
            'description' => 'An open-ended, ongoing vocal program for students who want continued riyaz (practice) discipline without committing to one specific style track.',
            'outcomes' => ['Consistent riyaz (practice) habits', 'Voice health and warm-up routines', 'Style-flexible repertoire building', 'Regular progress check-ins'],
        ],

        // ---------------- CHOREOGRAPHY: LEARN ----------------
        'choreography-foundations' => [
            'title' => 'Choreography Foundations', 'category' => 'choreography', 'subcategory' => 'learn',
            'instructor' => 'royan-mehta', 'level' => 'Beginner', 'duration' => '8 Weeks',
            'mode' => 'In-Studio', 'price' => '₹2,199/month', 'price_note' => 'Sample Pricing',
            'image' => IMG_STUDIO,
            'excerpt' => 'Learn to build and structure choreography, not just perform it.',
            'description' => 'For dancers who want to move from performing choreography to creating it — structuring a routine, counting music, and directing a group.',
            'outcomes' => ['Reading and counting music for choreography', 'Structuring a routine (formations, transitions)', 'Basic group directing skills', 'An original short choreographed piece'],
        ],
        'stage-performance-choreography-learn' => [
            'title' => 'Stage Performance Choreography', 'category' => 'choreography', 'subcategory' => 'learn',
            'instructor' => 'royan-mehta', 'level' => 'Intermediate', 'duration' => '8 Weeks',
            'mode' => 'In-Studio', 'price' => '₹2,499/month', 'price_note' => 'Sample Pricing',
            'image' => IMG_STUDIO,
            'excerpt' => 'Advanced choreography techniques for staged, ensemble performance work.',
            'description' => 'Builds on choreography fundamentals with a focus on staging for a real audience — blocking, spacing, and directing a full ensemble piece.',
            'outcomes' => ['Advanced formation and blocking work', 'Directing a full ensemble piece', 'Working with music edits and cues', 'A staged group performance'],
        ],

        // ---------------- CHOREOGRAPHY: HIRE (event services) ----------------
        'wedding-choreography' => [
            'title' => 'Wedding Choreography', 'category' => 'choreography', 'subcategory' => 'wedding',
            'instructor' => null, 'level' => 'N/A (Service)', 'duration' => 'Custom (per event)',
            'mode' => 'On-Location', 'price' => '₹9,999', 'price_note' => 'Starting From',
            'image' => IMG_KATHAKALI,
            'excerpt' => 'Choreography and rehearsal support for sangeet and wedding performances.',
            'description' => 'The academy\'s choreography team works with the wedding party to design, teach, and rehearse a performance — timeline and scope discussed directly with you.',
            'outcomes' => ['A custom-choreographed routine', 'Structured rehearsal sessions ahead of the event', 'On-the-day coordination support (by arrangement)', 'Music editing assistance (by arrangement)'],
        ],
        'school-function-choreography' => [
            'title' => 'School Function Choreography', 'category' => 'choreography', 'subcategory' => 'school',
            'instructor' => null, 'level' => 'N/A (Service)', 'duration' => 'Custom (per event)',
            'mode' => 'On-Location', 'price' => '₹6,999', 'price_note' => 'Starting From',
            'image' => IMG_MARCHING_BAND,
            'excerpt' => 'Choreography support for school annual days, functions, and assemblies.',
            'description' => 'Group choreography designed and taught for school events, scaled to the age group and number of students involved.',
            'outcomes' => ['Age-appropriate group choreography', 'On-site or in-school rehearsal sessions', 'Costume and formation guidance', 'Support on the day of the event (by arrangement)'],
        ],
        'college-function-choreography' => [
            'title' => 'College Function Choreography', 'category' => 'choreography', 'subcategory' => 'college',
            'instructor' => null, 'level' => 'N/A (Service)', 'duration' => 'Custom (per event)',
            'mode' => 'On-Location', 'price' => '₹7,999', 'price_note' => 'Starting From',
            'image' => IMG_MARCHING_BAND,
            'excerpt' => 'Choreography for college fests, competitions, and cultural events.',
            'description' => 'Choreography designed for the higher energy and competitive context of college cultural events and fests.',
            'outcomes' => ['Competition-oriented choreography', 'Group rehearsal scheduling', 'Music selection and editing guidance', 'Formation work for larger groups'],
        ],
        'corporate-event-choreography' => [
            'title' => 'Corporate Event Choreography', 'category' => 'choreography', 'subcategory' => 'corporate',
            'instructor' => null, 'level' => 'N/A (Service)', 'duration' => 'Custom (per event)',
            'mode' => 'On-Location', 'price' => '₹12,999', 'price_note' => 'Starting From',
            'image' => IMG_FESTIVAL,
            'excerpt' => 'Choreography for corporate offsites, annual days, and team performances.',
            'description' => 'Designed for employees with limited rehearsal time — accessible choreography built for a corporate performance, not a dance background.',
            'outcomes' => ['Beginner-friendly group choreography', 'Compressed rehearsal schedules for working professionals', 'Formation guidance for larger corporate groups', 'On-the-day support (by arrangement)'],
        ],
        'party-choreography' => [
            'title' => 'Party Choreography', 'category' => 'choreography', 'subcategory' => 'party',
            'instructor' => null, 'level' => 'N/A (Service)', 'duration' => 'Custom (per event)',
            'mode' => 'On-Location', 'price' => '₹4,999', 'price_note' => 'Starting From',
            'image' => IMG_BIRTHDAY_PARTY,
            'excerpt' => 'Light, fun choreography for birthdays, engagements, and private parties.',
            'description' => 'A shorter-scope service for one-off private parties — a fun, low-pressure routine rather than a formal show.',
            'outcomes' => ['A short, fun group routine', '1–2 rehearsal sessions', 'Music selection guidance', 'On-the-day walkthrough'],
        ],
        'cultural-event-choreography' => [
            'title' => 'Cultural Event Choreography', 'category' => 'choreography', 'subcategory' => 'cultural',
            'instructor' => null, 'level' => 'N/A (Service)', 'duration' => 'Custom (per event)',
            'mode' => 'On-Location', 'price' => '₹8,999', 'price_note' => 'Starting From',
            'image' => IMG_KATHAKALI,
            'excerpt' => 'Choreography for community cultural programs and festival celebrations.',
            'description' => 'Choreography rooted in traditional and folk vocabulary, designed for community cultural programs and festival celebrations.',
            'outcomes' => ['Culturally-grounded group choreography', 'Rehearsal scheduling around community availability', 'Costume and prop guidance', 'On-the-day coordination (by arrangement)'],
        ],
        'annual-function-choreography' => [
            'title' => 'Annual Function Choreography', 'category' => 'choreography', 'subcategory' => 'annual',
            'instructor' => null, 'level' => 'N/A (Service)', 'duration' => 'Custom (per event)',
            'mode' => 'On-Location', 'price' => '₹7,499', 'price_note' => 'Starting From',
            'image' => IMG_MARCHING_BAND,
            'excerpt' => 'End-to-end choreography for institutional annual day celebrations.',
            'description' => 'Built for the scale and formality of an annual day — typically multiple groups or age bands performing across one program.',
            'outcomes' => ['Choreography across multiple performance slots', 'Coordinated rehearsal calendar', 'Stage plotting for a full program', 'On-the-day coordination (by arrangement)'],
        ],
        'office-function-choreography' => [
            'title' => 'Office Function Choreography', 'category' => 'choreography', 'subcategory' => 'office',
            'instructor' => null, 'level' => 'N/A (Service)', 'duration' => 'Custom (per event)',
            'mode' => 'On-Location', 'price' => '₹5,999', 'price_note' => 'Starting From',
            'image' => IMG_FESTIVAL,
            'excerpt' => 'Quick-turnaround choreography for office celebrations and team events.',
            'description' => 'A lighter-scope version of the corporate service, suited to smaller office celebrations rather than large offsites.',
            'outcomes' => ['A short, accessible group routine', 'Compressed rehearsal schedule', 'Music selection guidance', 'On-the-day walkthrough'],
        ],
        'private-function-choreography' => [
            'title' => 'Private Function Choreography', 'category' => 'choreography', 'subcategory' => 'private',
            'instructor' => null, 'level' => 'N/A (Service)', 'duration' => 'Custom (per event)',
            'mode' => 'On-Location', 'price' => '₹4,499', 'price_note' => 'Starting From',
            'image' => IMG_BIRTHDAY_PARTY,
            'excerpt' => 'Choreography for family celebrations, milestone birthdays, and private gatherings.',
            'description' => 'The most flexible-scope service, tailored individually for family milestones and private celebrations of any size.',
            'outcomes' => ['A custom routine scaled to your group', 'Flexible rehearsal scheduling', 'Music and formation guidance', 'On-the-day support (by arrangement)'],
        ],
    ];
}

/**
 * Fetches any admin-edited price overrides from the database.
 * Returns an empty array (never throws) if the database isn't reachable,
 * so public pages keep working with static prices even without MySQL set up.
 */
function _get_course_price_overrides(): array
{
    static $overrides = null;
    if ($overrides !== null) {
        return $overrides;
    }
    $overrides = [];
    try {
        require_once __DIR__ . '/config.php';
        $rows = db()->query('SELECT course_slug, price, price_note FROM course_overrides')->fetchAll();
        foreach ($rows as $row) {
            $overrides[$row['course_slug']] = ['price' => $row['price'], 'price_note' => $row['price_note']];
        }
    } catch (Throwable $e) {
        // Database not configured/reachable — fall back to static prices.
    }
    return $overrides;
}

/**
 * Active courses from the admin-managed `courses` table, same shape as the
 * static array. Null => table empty/unreachable => static data is used.
 */
function _get_courses_from_db(): ?array
{
    static $cache = false;
    if ($cache !== false) {
        return $cache;
    }
    $cache = null;
    try {
        require_once __DIR__ . '/config.php';
        $rows = db()->query(
            "SELECT c.*, cat.slug AS cat_slug, sc.slug AS sub_slug
               FROM courses c
               JOIN categories cat ON cat.id = c.category_id
          LEFT JOIN subcategories sc ON sc.id = c.subcategory_id
              WHERE c.status = 'active' ORDER BY c.id"
        )->fetchAll();
        $total = (int) db()->query('SELECT COUNT(*) FROM courses')->fetchColumn();
        if ($total === 0) {
            return $cache;
        }
        $out = [];
        foreach ($rows as $r) {
            $out[$r['slug']] = [
                'title' => $r['title'], 'category' => $r['cat_slug'], 'subcategory' => (string) $r['sub_slug'],
                'instructor' => (string) $r['instructor_slug'], 'level' => $r['level'], 'duration' => $r['duration'],
                'mode' => $r['mode'], 'price' => $r['price'], 'price_note' => $r['price_note'],
                'image' => $r['image'] ?: IMG_KATHAKALI, 'excerpt' => (string) $r['excerpt'],
                'description' => (string) $r['description'],
                'outcomes' => array_values(array_filter(array_map('trim', preg_split('/\R/', (string) $r['outcomes'])))),
            ];
        }
        $cache = $out;
    } catch (Throwable $e) {
        // fall back to static
    }
    return $cache;
}

/** The raw static course entry, with NO price override applied. */
function get_course_static(string $slug): ?array
{
    $courses = _get_courses_static();
    return $courses[$slug] ?? null;
}

/** All courses, with any admin-saved price overrides applied. */
function get_courses(): array
{
    $fromDb = _get_courses_from_db();
    if ($fromDb !== null) {
        return $fromDb;
    }
    $courses   = _get_courses_static();
    $overrides = _get_course_price_overrides();

    foreach ($overrides as $slug => $override) {
        if (isset($courses[$slug])) {
            $courses[$slug]['price']      = $override['price'];
            $courses[$slug]['price_note'] = $override['price_note'];
        }
    }

    return $courses;
}

function get_course(string $slug): ?array
{
    $courses = get_courses();
    return $courses[$slug] ?? null;
}

function get_courses_by_category(string $category): array
{
    return array_filter(get_courses(), fn($c) => $c['category'] === $category);
}

// ---------------------------------------------------------------------------
// Instructors
//
// IMPORTANT: none of the names below refer to real public figures.
// (The brief that inspired this project listed several real, well-known
// singers as instructor names; those have been replaced with fictional
// names here — presenting real celebrities as affiliated with a
// fictional academy, even labeled "demo," risks implying a real-world
// association that doesn't exist. See README.md for the full note.)
// ---------------------------------------------------------------------------
function _get_instructors_static(): array
{
    return [
        'royan-mehta' => [
            'name' => 'Royan Mehta', 'specialty' => 'Bollywood & Contemporary Dance', 'category' => 'dance',
            'intro' => 'Focuses on building performance-ready choreography, from first-timers to competition teams.',
            'bio' => 'Demo Instructor profile. Royan leads the academy\'s Bollywood, contemporary, and choreography-focused courses, with an emphasis on making choreography feel achievable for beginners while still challenging advanced students.',
            'image' => IMG_INS_1,
        ],
        'dr-kavya-nair' => [
            'name' => 'Dr. Kavya Nair', 'specialty' => 'Classical Dance (Bharatanatyam)', 'category' => 'dance',
            'intro' => 'Structures classical training around a grade-by-grade progression, from adavus to abhinaya.',
            'bio' => 'Demo Instructor profile. Dr. Nair teaches the academy\'s Bharatanatyam foundation and kids\' programs, with a focus on correct fundamentals from the very first class.',
            'image' => IMG_INS_2,
        ],
        'meera-iyer' => [
            'name' => 'Meera Iyer', 'specialty' => 'Classical Dance (Kathak)', 'category' => 'dance',
            'intro' => 'Balances technical footwork training with the storytelling side of Kathak.',
            'bio' => 'Demo Instructor profile. Meera teaches Kathak foundations and the academy\'s advanced stage performance training, focusing on expression as much as technique.',
            'image' => IMG_DANCE,
        ],
        'ananya-rao' => [
            'name' => 'Ananya Rao', 'specialty' => 'Folk & Garba Dance', 'category' => 'dance',
            'intro' => 'Brings regional folk traditions into structured, beginner-friendly classes.',
            'bio' => 'Demo Instructor profile. Ananya leads the academy\'s folk, Garba, and group dance performance courses, with a focus on the cultural context behind each style.',
            'image' => IMG_FESTIVAL,
        ],
        'akash-gupta' => [
            'name' => 'Akash Gupta', 'specialty' => 'Group Singing & Vocal Training', 'category' => 'singing',
            'intro' => 'Runs the academy\'s general vocal training and group singing workshops.',
            'bio' => 'Demo Instructor profile. Akash teaches ongoing vocal training and group singing, focused on building consistent practice habits over flashy quick results.',
            'image' => IMG_BAND_PERFORMANCE,
        ],
        'nikhil-bansal' => [
            'name' => 'Nikhil Bansal', 'specialty' => 'Classical & Devotional Singing', 'category' => 'singing',
            'intro' => 'Teaches classical vocal foundations alongside devotional (bhajan) repertoire.',
            'bio' => 'Demo Instructor profile. Nikhil teaches the academy\'s classical vocal foundation and devotional singing courses, emphasizing breath and swara fundamentals.',
            'image' => IMG_INS_3,
        ],
        'arnav-chatterjee' => [
            'name' => 'Arnav Chatterjee', 'specialty' => 'Bollywood Singing', 'category' => 'singing',
            'intro' => 'Focuses on pitch accuracy and phrasing for contemporary film-song singing.',
            'bio' => 'Demo Instructor profile. Arnav teaches Bollywood vocal training, with a focus on translating raw enthusiasm for singing into technically solid performance.',
            'image' => IMG_INS_4,
        ],
        'priyanka-sethi' => [
            'name' => 'Priyanka Sethi', 'specialty' => 'Folk & Patriotic Singing', 'category' => 'singing',
            'intro' => 'Leads folk singing and the seasonal patriotic singing program.',
            'bio' => 'Demo Instructor profile. Priyanka teaches folk singing traditions and the academy\'s seasonal patriotic singing program for school and community events.',
            'image' => IMG_INS_5,
        ],
        'vidya-krishnan' => [
            'name' => 'Vidya Krishnan', 'specialty' => 'Kids Vocal Training', 'category' => 'singing',
            'intro' => 'Specialises in making singing approachable and fun for young children.',
            'bio' => 'Demo Instructor profile. Vidya teaches the academy\'s kids vocal basics program, prioritising confidence and enjoyment over technical pressure at a young age.',
            'image' => IMG_INS_6,
        ],
        'devansh-oberoi' => [
            'name' => 'Devansh Oberoi', 'specialty' => 'Stage Singing & Performance', 'category' => 'singing',
            'intro' => 'Works with students who already sing well on stage presence and delivery.',
            'bio' => 'Demo Instructor profile. Devansh teaches the academy\'s stage singing preparation course, focused on microphone technique and performance confidence.',
            'image' => IMG_STUDIO_BAND,
        ],
    ];
}

/**
 * Instructors: admin-managed `tutors` table first (active only), falling
 * back to the built-in demo profiles when the table is empty/unreachable.
 */
function get_instructors(): array
{
    static $cache = null;
    if ($cache !== null) {
        return $cache;
    }
    $cache = _get_instructors_static();
    try {
        require_once __DIR__ . '/config.php';
        if ((int) db()->query('SELECT COUNT(*) FROM tutors')->fetchColumn() > 0) {
            $cache = [];
            foreach (db()->query("SELECT * FROM tutors WHERE status = 'active' ORDER BY id")->fetchAll() as $t) {
                $cache[$t['slug']] = [
                    'name' => $t['name'], 'specialty' => $t['specialization'], 'category' => $t['category'],
                    'intro' => (string) $t['intro'], 'bio' => (string) $t['bio'],
                    'image' => $t['image'] ?: IMG_STUDIO_BAND,
                    'experience' => (string) $t['experience'], 'qualification' => (string) $t['qualification'],
                ];
            }
        }
    } catch (Throwable $e) {
        // keep static
    }
    return $cache;
}

function get_instructor(string $slug): ?array
{
    $instructors = get_instructors();
    return $instructors[$slug] ?? null;
}

function get_instructors_by_category(string $category): array
{
    return array_filter(get_instructors(), fn($i) => $i['category'] === $category);
}

// ---------------------------------------------------------------------------
// Testimonials — clearly labeled as sample/demo content, not real reviews.
// ---------------------------------------------------------------------------
function get_testimonials(): array
{
    return [
        ['quote' => 'The team was friendly and responsive throughout the enrollment process. The instructor explained every step clearly and adjusted the sessions according to my level.', 'name' => 'Dance Student', 'service' => 'Classical Dance'],
        ['quote' => 'We booked choreography support for a family event. The team helped us organize the practice sessions and communicated the requirements clearly from the start.', 'name' => 'Private Function Client', 'service' => 'Choreography Service'],
        ['quote' => 'My child looks forward to class every week. The instructor is patient and keeps things structured without making it feel like pressure.', 'name' => 'Parent of Student', 'service' => 'Kids Dance'],
        ['quote' => 'I came back to singing as an adult after years away. The one-on-one pacing made it realistic to actually stick with it this time.', 'name' => 'Vocals Student', 'service' => 'Vocal Training'],
        ['quote' => 'Our school\'s annual day choreography came together faster than I expected, and the team was easy to coordinate with around our schedule.', 'name' => 'School Function Coordinator', 'service' => 'School Function Choreography'],
        ['quote' => 'The Garba workshop ahead of Navratri was a great short-term option — no long commitment, just solid preparation before the season.', 'name' => 'Workshop Participant', 'service' => 'Garba & Regional Dance'],
    ];
}

// ---------------------------------------------------------------------------
// Gallery — sample photo categories.
// ---------------------------------------------------------------------------
function get_gallery(): array
{
    return [
        ['image' => IMG_BHARATANATYAM,    'category' => 'Dance',        'caption' => 'Dramatic Bharatanatyam performance pose'],
        ['image' => IMG_KATHAKALI,        'category' => 'Dance',        'caption' => 'Kathakali dancers in full traditional costume'],
        ['image' => IMG_KATHAKALI_2,      'category' => 'Dance',        'caption' => 'Kathakali — expressive eyes and traditional face painting'],
        ['image' => IMG_KATHAKALI_3,      'category' => 'Dance',        'caption' => 'Kathakali performer in a dramatic stance'],
        ['image' => IMG_KATHAKALI_4,      'category' => 'Dance',        'caption' => 'Kathakali crown and costume detail'],
        ['image' => IMG_MANIPURI_1,       'category' => 'Dance',        'caption' => 'Classical dance performance, expressive gesture'],
        ['image' => IMG_MANIPURI_2,       'category' => 'Dance',        'caption' => 'Classical dance performance, close angle'],
        ['image' => IMG_STUDIO_BAND,      'category' => 'Music',        'caption' => 'Rehearsal session — vocals, guitar, and drums'],
        ['image' => IMG_BAND_PERFORMANCE, 'category' => 'Music',        'caption' => 'A four-piece band performing live'],
        ['image' => IMG_GUITAR_CLOSEUP,   'category' => 'Music',        'caption' => 'Close-up of guitar technique on stage'],
        ['image' => IMG_MARCHING_BAND,    'category' => 'Choreography', 'caption' => 'A large marching band in formation'],
        ['image' => IMG_CONCERT_CROWD,    'category' => 'Performances', 'caption' => 'Crowd energy at a live performance'],
        ['image' => IMG_FESTIVAL_STAGE,   'category' => 'Events',       'caption' => 'Festival stage lighting rig'],
        ['image' => IMG_BIRTHDAY_PARTY,   'category' => 'Events',       'caption' => 'A private celebration in full swing'],
    ];
}

// ---------------------------------------------------------------------------
// Events — clearly sample/future events, not claiming specific confirmed dates.
// ---------------------------------------------------------------------------
function get_events(): array
{
    return [
        ['title' => 'Dance Workshop — Garba Intensive', 'type' => 'Workshop', 'date' => '[DATE TO BE CONFIRMED]', 'location' => '[LOCATION TO BE CONFIRMED]', 'image' => IMG_MANIPURI_1, 'description' => 'A short intensive ahead of the Navratri season, open to all levels.'],
        ['title' => 'Singing Workshop — Classical Fundamentals', 'type' => 'Workshop', 'date' => '[DATE TO BE CONFIRMED]', 'location' => '[LOCATION TO BE CONFIRMED]', 'image' => IMG_STUDIO_BAND, 'description' => 'A weekend workshop covering swara and taal basics for new students.'],
        ['title' => 'Student Recital', 'type' => 'Performance', 'date' => '[DATE TO BE CONFIRMED]', 'location' => '[LOCATION TO BE CONFIRMED]', 'image' => IMG_BHARATANATYAM, 'description' => 'A showcase performance for current dance and singing students.'],
        ['title' => 'Cultural Program', 'type' => 'Cultural Event', 'date' => '[DATE TO BE CONFIRMED]', 'location' => '[LOCATION TO BE CONFIRMED]', 'image' => IMG_KATHAKALI, 'description' => 'A community cultural program featuring student and faculty performances.'],
        ['title' => 'Music Session — Open Practice', 'type' => 'Music Session', 'date' => '[DATE TO BE CONFIRMED]', 'location' => '[LOCATION TO BE CONFIRMED]', 'image' => IMG_BAND_PERFORMANCE, 'description' => 'An informal open practice session for enrolled vocal students.'],
    ];
}

// ---------------------------------------------------------------------------
// FAQ
// ---------------------------------------------------------------------------
function get_faqs(): array
{
    return [
        ['q' => 'Do you offer online classes?', 'a' => 'Yes — several courses offer an online option alongside in-studio sessions. Each course page notes which modes are available.'],
        ['q' => 'Do you offer in-studio classes?', 'a' => 'Yes, most courses are taught in-studio, and several combine online and in-studio sessions.'],
        ['q' => 'Are beginner students welcome?', 'a' => 'Yes — most courses are designed for complete beginners, with level noted clearly on each course page.'],
        ['q' => 'Do you provide children\'s classes?', 'a' => 'Yes, there are dedicated kids\' programs in both dance and singing, paced appropriately for younger students.'],
        ['q' => 'Do you provide wedding choreography?', 'a' => 'Yes — wedding choreography is offered as an event service, separate from the regular learning courses. See the Choreography section for details.'],
        ['q' => 'Can schools contact the academy for performances?', 'a' => 'Yes, school function choreography is one of our event services — reach out via the contact page with your event details.'],
        ['q' => 'Do you offer group classes?', 'a' => 'Yes — several courses, like Group Dance Performance and Group Singing Workshop, are specifically structured around group skills.'],
        ['q' => 'Can I contact the academy for custom choreography?', 'a' => 'Yes — use the contact page to describe your event and requirements, and the team will follow up to discuss scope and timing.'],
    ];
}
