<footer class="site-footer">
  <div class="container">
    <div class="footer-grid">
      <div>
        <div class="brand" style="margin-bottom:14px;">
          <img src="assets/images/logo.png" alt="Aadhiya Shakti Academy logo" class="brand-logo">
          Aadhiya Shakti Academy
        </div>
        <p style="max-width:280px; color:rgba(37,37,37,0.6); font-size:0.9rem;">
          A dance, singing, music and choreography academy — structured courses
          and event choreography services, taught with attention to craft.
        </p>
        <div class="footer-social">
          <a href="[OFFICIAL INSTAGRAM URL]" aria-label="Instagram">Instagram</a>
          <a href="[OFFICIAL X URL]" aria-label="X / Twitter">X / Twitter</a>
        </div>
      </div>

      <div>
        <h4>Quick Links</h4>
        <ul>
          <li><a href="index.php">Home</a></li>
          <li><a href="about.php">About</a></li>
          <li><a href="courses.php">Courses</a></li>
          <li><a href="instructors.php">Instructors</a></li>
          <li><a href="gallery.php">Gallery</a></li>
          <li><a href="events.php">Events</a></li>
          <li><a href="services.php">Services</a></li>
          <li><a href="testimonials.php">Testimonials</a></li>
          <li><a href="contact.php">Contact</a></li>
        </ul>
      </div>

      <div>
        <h4>Courses</h4>
        <ul>
          <li><a href="courses.php?category=dance">Dance</a></li>
          <li><a href="courses.php?category=singing">Singing</a></li>
          <li><a href="courses.php?category=choreography">Choreography</a></li>
        </ul>
      </div>

      <div>
        <h4>Contact</h4>
        <ul>
          <li>Email: [EMAIL TO BE CONFIRMED]</li>
          <li>Phone: [PHONE NUMBER TO BE CONFIRMED]</li>
          <li>Location: [CITY / SERVICE AREA TO BE CONFIRMED]</li>
        </ul>
      </div>
    </div>

    <div class="footer-bottom">
      <span>&copy; <?= date('Y') ?> Aadhiya Shakti Academy. All rights reserved.</span>
      <span style="opacity:0.6;">Demo project — contact details above are placeholders.</span>
    </div>
  </div>
</footer>

<script src="assets/js/main.js"></script>
</body>
</html>
