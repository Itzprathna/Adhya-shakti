<?php
$page_title = 'Instructors — Aadhiya Shakti Academy';
$page_description = 'Meet the demo instructor profiles for Aadhiya Shakti Academy\'s dance and singing programs.';
require_once __DIR__ . '/includes/header.php';
require_once __DIR__ . '/includes/data.php';

$instructors = get_instructors();
?>

<section class="page-header">
  <div class="container">
    <span class="eyebrow">Meet The Faculty</span>
    <h1>Instructors</h1>
    <p>All profiles below are demo instructor content created for this project — not real academy staff. See About for more on this.</p>
  </div>
</section>

<section style="padding-top:0;">
  <div class="container">
    <div class="instructor-grid">
      <?php foreach ($instructors as $slug => $person): ?>
        <div class="instructor-card reveal">
          <div class="img-tint img-tint--<?= $person['category'] === 'dance' ? 'dance' : 'singing' ?>">
            <img src="<?= $person['image'] ?>" alt="Artistic action shot representing <?= htmlspecialchars($person['specialty']) ?>" loading="lazy">
          </div>
          <div class="instructor-card-body">
            <span class="demo-badge">Demo Instructor</span>
            <h3><?= htmlspecialchars($person['name']) ?></h3>
            <div class="specialty"><?= htmlspecialchars($person['specialty']) ?></div>
            <p class="intro"><?= htmlspecialchars($person['intro']) ?></p>
            <a href="instructor-detail.php?instructor=<?= $slug ?>" class="btn btn-outline btn-sm">View Profile</a>
          </div>
        </div>
      <?php endforeach; ?>
    </div>
  </div>
</section>

<?php require_once __DIR__ . '/includes/footer.php'; ?>
