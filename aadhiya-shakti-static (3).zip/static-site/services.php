<?php
$page_title = 'Services — Aadhiya Shakti Academy';
$page_description = 'Dance training, singing training, and choreography services offered by Aadhiya Shakti Academy.';
require_once __DIR__ . '/includes/header.php';
require_once __DIR__ . '/includes/data.php';
?>

<section class="page-header">
  <div class="container">
    <span class="eyebrow">What We Offer</span>
    <h1>Services</h1>
    <p>Structured training in dance and singing, plus a dedicated choreography service for events.</p>
  </div>
</section>

<section style="padding-top:0;">
  <div class="container">

    <div class="service-block">
      <div class="service-media img-tint img-tint--dance"><img src="<?= IMG_MANIPURI_2 ?>" alt="Dance training at the academy" loading="lazy"></div>
      <div>
        <span class="eyebrow">Learn</span>
        <h2>Dance Training</h2>
        <p style="color:var(--charcoal-soft); margin-top:10px;">Structured courses across classical, folk, and contemporary styles for every age group.</p>
        <ul class="service-list">
          <li>Classical (Bharatanatyam, Kathak)</li>
          <li>Folk &amp; Garba</li>
          <li>Bollywood &amp; Contemporary</li>
          <li>Group &amp; Kids Dance</li>
        </ul>
        <a href="courses.php?category=dance" class="btn btn-primary">Explore Dance Courses</a>
      </div>
    </div>

    <div class="service-block">
      <div class="service-media img-tint img-tint--singing"><img src="<?= IMG_STUDIO_BAND ?>" alt="Singing training at the academy" loading="lazy"></div>
      <div>
        <span class="eyebrow">Learn</span>
        <h2>Singing Training</h2>
        <p style="color:var(--charcoal-soft); margin-top:10px;">Vocal training across classical, folk, devotional, and contemporary styles.</p>
        <ul class="service-list">
          <li>Classical &amp; Devotional Singing</li>
          <li>Folk &amp; Bollywood Singing</li>
          <li>Group Singing &amp; Vocal Training</li>
          <li>Kids Vocal Basics</li>
        </ul>
        <a href="courses.php?category=singing" class="btn btn-primary">Explore Singing Courses</a>
      </div>
    </div>

    <div class="service-block">
      <div class="service-media img-tint img-tint--studio"><img src="<?= IMG_GUITAR_CLOSEUP ?>" alt="Choreography training at the academy" loading="lazy"></div>
      <div>
        <span class="eyebrow">Learn Choreography</span>
        <h2>Learn to Choreograph</h2>
        <p style="color:var(--charcoal-soft); margin-top:10px;">For dancers who want to move from performing choreography to creating it — structure, formations, and directing a group.</p>
        <ul class="service-list">
          <li>Choreography Foundations</li>
          <li>Stage Performance Choreography</li>
        </ul>
        <a href="courses.php?category=choreography&subcategory=learn" class="btn btn-primary">View Choreography Courses</a>
      </div>
    </div>

    <div class="service-block">
      <div class="service-media img-tint img-tint--choreo"><img src="<?= IMG_MARCHING_BAND ?>" alt="Choreography service for events" loading="lazy"></div>
      <div>
        <span class="eyebrow">Hire</span>
        <h2>Choreography Services for Events</h2>
        <p style="color:var(--charcoal-soft); margin-top:10px;">The academy's choreography team designs, teaches, and rehearses a performance for your event.</p>
        <ul class="service-list">
          <li>Weddings &amp; Sangeets</li>
          <li>School, College &amp; Annual Functions</li>
          <li>Corporate &amp; Office Events</li>
          <li>Parties &amp; Private Functions</li>
        </ul>
        <a href="contact.php" class="btn btn-coral">Discuss Your Event</a>
      </div>
    </div>

  </div>
</section>

<?php require_once __DIR__ . '/includes/footer.php'; ?>
